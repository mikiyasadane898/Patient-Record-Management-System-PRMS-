<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body>

    <!-- Sale & Revenue Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-line fa-3x text-primary"></i>
                    <div class="ms-3">
                        <p class="mb-2">Number of Patient</p>
                        <?php
                        require 'Connection.php';
                        require 'dash.php';

                        $data = countPatient();
                        foreach ($data as $row) {
                            echo '<h6 class="mb-0">' . $row['COUNT(Patient_id)'] . '</h6>';
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <?php
                    require 'Connection.php';


                    $data = countUser();
                    foreach ($data as $row) {
                    ?>

                        <i class="fa fa-chart-line fa-3x text-primary"></i>
                        <div class="ms-3">
                            <?php
                            echo '<p class="mb-2">' . "Number of users" . '</p>';
                            echo '<h6 class="mb-0">' . $row['COUNT(User_id)'] . '</h6>';
                            ?>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <?php
                    require 'Connection.php';


                    $data = countinsurance();
                    foreach ($data as $row) {
                    ?>

                        <i class="fa fa-chart-line fa-3x text-primary"></i>
                        <div class="ms-3">
                            <?php
                            echo '<p class="mb-2">' . "insurance services" . '</p>';
                            echo '<h6 class="mb-0">' . $row['COUNT(Patient_id)'] . '</h6>';
                            ?>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <?php
                    require 'Connection.php';


                    $data = countsale();
                    foreach ($data as $row) {
                    ?>

                        <i class="fa fa-chart-line fa-3x text-primary"></i>
                        <div class="ms-3">
                            <?php
                            echo '<p class="mb-2">' . "sale services" . '</p>';
                            echo '<h6 class="mb-0">' . $row['COUNT(Patient_id)'] . '</h6>';
                            ?>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <?php
                    require 'Connection.php';


                    $data = counttest();
                    foreach ($data as $row) {
                    ?>

                        <i class="fa fa-chart-line fa-3x text-primary"></i>
                        <div class="ms-3">
                            <?php
                            echo '<p class="mb-2">' . "Test Types" . '</p>';
                            echo '<h6 class="mb-0">' . $row['COUNT(Test_Type)'] . '</h6>';
                            ?>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                    <?php
                    require 'Connection.php';


                    $data = countmedicine();
                    foreach ($data as $row) {
                    ?>

                        <i class="fa fa-chart-line fa-3x text-primary"></i>
                        <div class="ms-3">
                            <?php
                            echo '<p class="mb-2">' . "Test Types" . '</p>';
                            echo '<h6 class="mb-0">' . $row['COUNT(Medicine_id)'] . '</h6>';
                            ?>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>

        </div>
    </div>
    <!-- Sale & Revenue End -->

</body>

</html>
<?php
date_default_timezone_set('Africa/Nairobi');
require 'Connection.php';


if (isset($_POST["add"])) {
  addLabTestToDatabase();
  addSymptomsAndOthers();
}

if (isset($_POST["padd"])) {
  addPhysicalTestToDatabase();
  addSymptomsAndOthers();
}

if (isset($_POST['addprescription'])) {
  CalculateMedicinePrice();
  addPrescriptionToDatabase();
  addDocSuggesion();
}


function addLabTestToDatabase()
{
  session_start();

  require 'Connection.php';



  $clinicalDiagnosis = $_POST['lclinicaldiagnosis'];
  $testType = $_POST['selectlt'];
  $testName = $_POST['ltestname'];
  $patientid = $_SESSION['ip'];
  $date = date('m-d-y h:i:sa');
  $user_id = $_SESSION['user_id'];
  $description =  " For $testType Test ";
  $reason = "Test";
  $paymentmethod = $_POST['lpaymentmethod'];
  $quantity = "1";



  $sql = "INSERT INTO test_db (Patient_id, Clinical_Diagnosis, Test_type, Requested_Test, Doctor_id, Date) 
    Values ('$patientid', '$clinicalDiagnosis', '$testType',  '$testName', '$user_id', '$date')";
  $result = mysqli_query($conn, $sql);



  if ($result) {
    $Test_id = mysqli_insert_id($conn);
    $_SESSION['tid'] = $Test_id;
    $_SESSION['status'] = " Test and Symptoms Added Successfully";
    $_SESSION['status_code'] = "success";
    header("Location:../../fields/Doctor/AddTest.php?patient_id=$patientid?addTest=success");
  } else {
    $_SESSION['status'] = " Test and Symptoms Not Added  Successfully";
    $_SESSION['status_code'] = "error";
    header("Location:../../fields/Doctor/AddTest.php?patient_id=$patientid?addTest=error");
  }

  $sql1 = " SELECT Price FROM test_price_db WHERE Test_Type = '$testType'";
  $result2 = mysqli_query($conn, $sql1);
  if ($result2) {
    foreach ($result2 as $row) {
      $price = $row['Price'];
    }
  }

  if ($paymentmethod == "Cash") {
    $sql = "INSERT INTO bill (Patient_id, Quantity,Reason, Description, Unit_Price, Total_Price , Payment_Method, Date) Values (?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $patientid, $quantity, $reason, $description, $price, $price, $paymentmethod, $date);
    $stmt->execute();
  } else {
    $sql = "INSERT INTO insurance_db (Patient_id, Quantity,Reason, Description, Unit_Price, Total_Price , Payment_Method, Date) Values (?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $patientid, $quantity, $reason, $description, $price, $price, $paymentmethod, $date);
    $stmt->execute();
  }
}



function addPhysicalTestToDatabase()
{
  session_start();

  require 'Connection.php';



  $clinicalDiagnosis = $_POST['clinicaldiagnosis'];
  $testType = $_POST['selectpt'];
  $testName = $_POST['testname'];

  $patientid = $_SESSION['ip'];
  $date = date('m-d-y h:i:sa');
  $user_id = $_SESSION['user_id'];
  $description =  " For $testType Test ";
  $reason = "Test";
  $paymentmethod = $_POST['ppaymentmethod'];
  $quantity = "1";




  $sql = "INSERT INTO test_db (Patient_id,  Clinical_Diagnosis, Test_type, Requested_Test, Doctor_id, Date)
     Values (?,?,?,?,?,?)";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("ssssss", $patientid, $clinicalDiagnosis, $testType,  $testName, $user_id, $date);
  $result2 = $stmt->execute();

  if ($result2) {
    $Test_id = mysqli_insert_id($conn);
    $_SESSION['tid'] = $Test_id;
    $_SESSION['status'] = " Test and Symptoms Added Successfully";
    $_SESSION['status_code'] = "success";
    header("Location:../../fields/Doctor/AddTest.php?patient_id=$patientid?addTest=success");
  } else {
    $_SESSION['status'] = " Test and Symptoms Not Added  Successfully";
    $_SESSION['status_code'] = "error";
    header("Location:../../fields/Doctor/AddTest.php?patient_id=$patientid?addTest=error");
  }



  $sql1 = " SELECT Price FROM test_price_db WHERE Test_Type = '$testType'";
  $result = mysqli_query($conn, $sql1);
  if ($result) {
    foreach ($result as $row) {
      $price = $row['Price'];
    }
  }

  if ($paymentmethod == "Cash") {
    $sql = "INSERT INTO bill (Patient_id, Quantity,Reason, Description, Unit_Price, Total_Price , Payment_Method, Date) Values (?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $patientid, $quantity, $reason, $description, $price, $price, $paymentmethod, $date);
    $stmt->execute();
  } else {
    $sql = "INSERT INTO insurance_db (Patient_id, Quantity,Reason, Description, Unit_Price, Total_Price , Payment_Method, Date) Values (?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $patientid, $quantity, $reason, $description, $price, $price, $paymentmethod, $date);
    $stmt->execute();
  }
}




function addSymptomsAndOthers()
{

  require 'Connection.php';

  $T_id = $_SESSION['tid'];
  $patientid = $_SESSION['ip'];
  $symptom = $_POST['symptoms'];
  $date = date('m-d-y h:i:sa');
  $sql = " SELECT * FROM diagnosis_db WHERE Symptoms IS NULL AND Patient_id = '$patientid' ";
  $re = mysqli_query($conn, $sql);
  if ($re->num_rows > 0) {
    $sql1 = "UPDATE diagnosis_db SET Symptoms = '$symptom' , Test_id = '$T_id' 
  WHERE Patient_id = '$patientid' AND Symptoms IS NULL  ";
    $result1 = mysqli_query($conn, $sql1);
    if ($result1) {

      header("Location:../../fields/Doctor/AddTest.php?patient_id=$patientid?addSymptom=success");
    } else {
      echo "Error";
    }
  } else {
    $age = $_SESSION['age'];
    $finding = $_SESSION['finding'];
    $doctor_id = $_SESSION['user_id'];


    $sql = "INSERT INTO diagnosis_db (Patient_id,  Age, Finding, Symptoms, Test_id, Doctor_id, Date) VALUES 
  ('$patientid', '$age', '$finding',  '$symptom', '$T_id', '$doctor_id', '$date')";
    $result2 = mysqli_query($conn, $sql);
    if ($result2) {

      header("Location:../../fields/Doctor/AddTest.php?patient_id=$patientid?addSymptom=success");
    } else {
      echo "Error";
    }
  }
}


// function to Select list of result

function SelectResultFromDatabase()
{ 
  require 'Connection.php';
$uid = $_SESSION['user_id'];
  // SQL query to fetch data from the "myTable" table


  $sql1 = "SELECT DISTINCT(d.Age), p.Patient_id, p.FirstName, p.MiddleName, p.LastName, p.Sex FROM patient_db p INNER JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
  INNER JOIN test_db t ON d.Test_id = t.Test_id 
  INNER JOIN user_db u ON t.Doctor_id = u.User_id 
  WHERE d.Prescription_id IS NULL AND u.User_id = '$uid' AND (t.Test_Result != '')";

  $result = $conn->query($sql1);
  // Return data as an array

  return $result;
}

// function to select detail information about the test


function SelectDetailTestFromDatabase1()
{
  require 'Connection.php';
  if (!$conn) {
    die("Connection failed! :" . mysqli_connect_error());
  }
  $patientid = $_POST['patient_id'];
  $sql = " SELECT DISTINCT p.Patient_id, p.FirstName, p.MiddleName, p.LastName, p.Age, p.Sex, t.Date,  
  t.Patient_id,  t.Test_id, t.Clinical_Diagnosis, t.Test_Type,  t.Requested_Test, t.Test_Result, 
  t.Doctor_id, t.Professional_id, u.User_id
  FROM patient_db p
  JOIN test_db t ON p.Patient_id = t.Patient_id
  JOIN user_db u ON t.Doctor_id = u.User_id
  JOIN diagnosis_db d on p.Patient_id = d.Patient_id
  WHERE p.Patient_id = '$patientid' AND (t.Test_Result != '' AND d.Prescription_id IS NULL) ";

  // Execute the SQL statement
  $result = $conn->query($sql);


  return $result;
}



// function to select patient selected for each doctor



function SelectPatientSelectForDoctorFromDatabase()
{

  require 'Connection.php';

  $user_id = $_SESSION['user_id'];
  
  $sql = " SELECT DISTINCT p.Patient_id, p.FirstName, p.MiddleName, p.LastName, p.Sex, d.Age, d.Date, u.User_id, d.* FROM 
  patient_db p JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
  JOIN user_db u ON u.User_id = d.Doctor_id 
  JOIN bill b ON b.Patient_id = p.Patient_id 
  where d.Doctor_id = '$user_id' AND d.Symptoms IS NULL 
  AND b.Receipt_Number IS NOT NULL AND b.Reason = 'For Card';
  SELECT DISTINCT p.Patient_id, p.FirstName, p.MiddleName, p.LastName, p.Sex, d.Age, d.Date, u.User_id, d.* FROM 
  patient_db p JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
  JOIN user_db u ON u.User_id = d.Doctor_id 
  JOIN insurance_db i ON i.Patient_id = p.Patient_id 
  where d.Doctor_id = '$user_id' AND d.Symptoms IS NULL
   AND i.Insurance_code IS NOT NULL AND i.Reason = 'For Card' ";
  
  return $sql;
}

//function to select patients History
function SelectPatientToAddTestFromDatabase()
{


  require 'Connection.php';
  if (!$conn) {
    die("Connection failed! :" . mysqli_connect_error());
  }
  $patientid = $_GET['patient_id'];
  $sql = " SELECT * FROM patient_db p 
  JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
  JOIN test_db t ON d.Test_id = t.Test_id 
  JOIN user_db u ON d.Doctor_id = u.User_id 
  JOIN prescription_db pr ON d.Prescription_id = pr.Prescription_id 
  WHERE p.Patient_id = '$patientid'";


  // Execute the SQL statement
  $result = $conn->query($sql);


  return $result;
}


//function to select basic patient information 1

function selectTestID()
{
  require 'Connection.php';
  $patientid = $_SESSION['patient_id '];
  $test_id = $_GET["Test_id"];
 
  $sql = " SELECT DISTINCT(d.Age), p.Patient_id, p.FirstName, p.MiddleName, p.LastName,  p.Sex, t.Date, t.Test_id 
  FROM patient_db p INNER JOIN test_db t on p.Patient_id = t.Patient_id 
  INNER JOIN diagnosis_db d on p.Patient_id = d.Patient_id 
  WHERE p.Patient_id = ' $patientid' AND t.Test_id = '$test_id'  AND d.Prescription_id IS NULL";

  $result = mysqli_query($conn, $sql);

  return $result;
}



function selectPatientName()
{
  require 'Connection.php';
  $patientid  = $_GET["patient_id"];
  $sql = " SELECT DISTINCT(d.Age), p.Patient_id, p.FirstName, p.MiddleName, p.LastName, p.Sex
   FROM patient_db p INNER JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
   INNER JOIN test_db t ON d.Test_id = t.Test_id 
  WHERE d.Prescription_id IS NULL AND (t.Test_Result != '') AND p.Patient_id = '$patientid'";

  $result = mysqli_query($conn, $sql);

  return $result;
}



//function to select basic patient information 2

function selectPatientNameAddTest()
{


  require 'Connection.php';
  $patientid = $_GET['patient_id'];
  $sql = "SELECT p.*, d.* FROM patient_db p 
  JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
  where d.Patient_id = '$patientid' AND d.Symptoms IS NULL;";

  $result = mysqli_query($conn, $sql);

  return $result;
}


function selectPatientFinding()
{


  require 'Connection.php';
  $patientid = $_GET['patient_id'];
  $sql = " SELECT * FROM diagnosis_db WHERE Patient_id = '$patientid' AND Symptoms IS NULL";

  $result = mysqli_query($conn, $sql);

  return $result;
}

function selectPatientSymptoms()
{
  require 'Connection.php';
  $patientid = $_SESSION['patient_id'];
  $ti = $_SESSION['Test_id'];
  $sql = " SELECT * FROM diagnosis_db WHERE Patient_id = '$patientid' AND Test_id = '$ti' AND Doctor_Suggestion IS NULL";

  $result = mysqli_query($conn, $sql);

  return $result;
}



function addPrescriptionToDatabase()
{
  session_start();


  require 'Connection.php';


  $medicinename = $_POST['selectm'];
  $dosage = $_POST['selectd'];
  $day = $_POST['day'];
  $perday = $_POST['perday'];
  $user_id = $_SESSION['user_id'];
  $totalprice = $_SESSION['totalprice'];
  $patientid = $_SESSION['patient_id '];
  $date = date('m-d-y h:i:sa');
  $reason = "Medicine";
  $description = "$medicinename, $dosage For $day Days";
  $quantity = $_SESSION['quantity'];
  $unitprice = $_SESSION['price'];
  $paymentmethod = $_POST['paymentmethod'];

$sql3 = "SELECT Remain_Amount FROM medicine_price_db WHERE Medicine_Name = $medicinename";
$re = mysqli_query($conn, $sql3);
foreach($re as $row){
  $remain = $row['Remain_Amount'];
}

if($remain >= $quantity){

  
  $sql = "INSERT INTO prescription_db (Patient_id, Medicine_name, Dose, Days, Per_Day, Doctor_id,  Date) 
    Values ('$patientid', '$medicinename', '$dosage', '$day', $perday, '$user_id', '$date')";
  $result1 = mysqli_query($conn, $sql);
  if ($result1) {
    $Prescription_id = mysqli_insert_id($conn);
    $_SESSION['prescriptionid'] = $Prescription_id;
  }

  if ($paymentmethod == "Cashe") {
    $sql = "INSERT INTO bill (Patient_id, Quantity,Reason, Description, Unit_Price, Total_Price , Payment_Method, Date) Values (?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $patientid, $quantity, $reason, $description, $unitprice, $totalprice, $paymentmethod, $date);
    $stmt->execute();
  } else {
    $sql = "INSERT INTO insurance_db (Patient_id, Quantity,Reason, Description, Unit_Price, Total_Price , Payment_Method, Date) Values (?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $patientid, $quantity, $reason, $description, $unitprice, $totalprice, $paymentmethod, $date);
    $stmt->execute();
  }

  if ($result1 && $stmt) {
    $data = selectPatient();
    if ($data->num_rows > 0) {
      $_SESSION['status'] = " Prescription Added Successfully";
      $_SESSION['status_code'] = "success";
      header("Location:../../fields/Doctor/Result.php?patient_id=$patientid?addPrescription=success");
    } else {
      $_SESSION['status'] = " Prescription Added  Successfully";
      $_SESSION['status_code'] = "success";
      header("Location:../../fields/Doctor/ViewResult.php?patient_id=$patientid?addPrescription=success");
    }
  } else {
    $_SESSION['status'] = " Prescription Not Added  Successfully";
    $_SESSION['status_code'] = "error";
    header("Location:../../fields/Doctor/Result.php?patient_id=$patientid?addPrescription=error");
  }
}else{
  $_SESSION['status'] = "Unavailable pils Amount Please Try Again ";
  $_SESSION['status_code'] = "error";
  header("Location:../../fields/Doctor/ViewResult.php?patient_id=$patientid?addPrescription=error");
}
}

function addDocSuggesion()
{

  require 'Connection.php';

  $test_id = $_SESSION['Test_id'];
  $docsuggestion = $_POST['docsug'];
  $patientid = $_SESSION['patient_id '];
  $Prescription_id = $_SESSION['prescriptionid'];

  $sql = "UPDATE diagnosis_db SET Doctor_Suggestion = '$docsuggestion', Prescription_id = '$Prescription_id' WHERE 
   Patient_id = '$patientid' AND Test_id = '$test_id'";
  $result = mysqli_query($conn, $sql);
  if ($result) {
    $data = selectPatient();
    if ($data->num_rows > 0) {
      $_SESSION['status'] = " Prescription Added Successfully";
      $_SESSION['status_code'] = "success";
      header("Location:../../fields/Doctor/Result.php?patient_id=$patientid?addPrescription=success");
    } else {
      $_SESSION['status'] = " Prescription Added  Successfully";
      $_SESSION['status_code'] = "success";
      header("Location:../../fields/Doctor/ViewResult.php?patient_id=$patientid?addPrescription=success");
    }
  } else {
    $_SESSION['status'] = " Prescription Not Added  Successfully";
    $_SESSION['status_code'] = "error";
    header("Location:../../fields/Doctor/Result.php?patient_id=$patientid?addPrescription=error");
  }
}


function addDocSuggesion1()
{
  session_start();

  require 'Connection.php';

  $test_id = $_SESSION['Test_id'];;
  $patientid = $_SESSION['ip'];
  $docsuggestion = $_POST['docsug'];
  $Prescription_id = $_SESSION['prescriptionid'];
  $date = date('m-d-y h:i:sa');
  $sql = " SELECT * FROM diagnosis_db WHERE Doctor_Suggestion IS NULL AND Patient_id = '$patientid' ";
  $re = mysqli_query($conn, $sql);
  if ($re->num_rows > 0) {
    $sql1 = "UPDATE diagnosis_db SET Doctor_Suggestion = '$docsuggestion' , Prescription_id = '$Prescription_id' 
  WHERE Patient_id = '$patientid' AND Doctor_Suggestion IS NULL AND Test_id = '$test_id'";
    $result1 = mysqli_query($conn, $sql1);
    if ($result1) {
      $data = selectPatient();
      if ($data->num_rows > 0) {
        header("Location:../../fields/Doctor/Result.php?patient_id=$patientid?login=success");
      } else {
        header("Location:../../fields/Doctor/ViewResult.php?login=success");
      }
    } else {
      echo "Error";
    }
  } else {
    $age = $_SESSION['age'];
    $finding = $_SESSION['finding'];
    $doctor_id = $_SESSION['user_id'];
    $symptom = $_SESSION['Symptoms'];


    $sql = "INSERT INTO diagnosis_db (Patient_id,  Age, Finding, Symptoms, Test_id,Doctor_Suggestion, Doctor_id, Date) VALUES 
  ('$patientid', '$age', '$finding',  '$symptom', '$T_id', '$docsuggestion', '$doctor_id', '$date')";
    $result2 = mysqli_query($conn, $sql);
    if ($result2) {
      $data = selectPatient();
      if ($data->num_rows > 0) {
        header("Location:../../fields/Doctor/Result.php?patient_id=$patientid?login=success");
      } else {
        header("Location:../../fields/Doctor/ViewResult.php?login=success");
      }
    } else {
      echo "Error";
    }
  }
}



function selectPatient()
{

  require 'Connection.php';
  $uid = $_SESSION['user_id'];
  $patient_id = $_GET['patient_id'];
  
$sql1 = "SELECT DISTINCT p.*, t.*, d.* FROM patient_db p   
INNER JOIN test_db t ON p.Patient_id = t.Patient_id
INNER JOIN user_db u ON t.Doctor_id = u.User_id 
INNER JOIN diagnosis_db d ON t.Test_id = d.Test_id 
WHERE t.Test_Result != '' AND d.Prescription_id IS NULL AND  t.Patient_id = '$patient_id' AND u.User_id = '$uid'";
  $result = $conn->query($sql1);

  return $result;
}


function CalculateMedicinePrice()
{
  require 'Connection.php';
  session_start();
  $patientid = $_SESSION['ip'];
  $medicinename = $_POST['selectm'];
  $dosage = $_POST['selectd'];
  $day = $_POST['day'];
  $perday = $_POST['perday'];

  $sql = " SELECT Price, Quantity, Sold_Amount, Remain_Amount FROM medicine_price_db 
    WHERE Medicine_Name = '$medicinename' AND Dos = '$dosage'";
  $result = mysqli_query($conn, $sql);

  if ($result) {
    foreach ($result as $row) {
      $price = $row['Price'];
      $quantity = $row['Quantity'];
      $soldamount = $row['Sold_Amount'];
      $remainamount = $row['Remain_Amount'];
    }
  }

  $pilsamount = $day * $perday;
  $totalprice = $price * $pilsamount;
  $soldamount = $soldamount + $pilsamount;
  $remainamount = $quantity - $soldamount;
  $_SESSION['price'] = $price;
  $_SESSION['quantity'] =  $pilsamount;
  $_SESSION['totalprice'] = $totalprice;

  if($remainamount > 0){
  $sql1 = " UPDATE medicine_price_db SET Sold_Amount = $soldamount, Remain_Amount =  $remainamount
  WHERE Medicine_Name = '$medicinename' AND Dos = '$dosage'";
  $result1 = mysqli_query($conn, $sql1);
  }
  else{
    $sql1 = "DELETE FROM medicine_price_db WHERE $remainamount <= 0";
    $result1 = mysqli_query($conn, $sql1);
  }
}

<?php
date_default_timezone_set('Africa/Nairobi');
session_start();


  require 'Connection.php';

  // accept values

  $medicinename = $_POST['selectm'];
  
  $day = $_POST['day'];
  $perday = $_POST['perday'];
  $user_id = $_SESSION['user_id'];
  $patientid = $_SESSION['patient_id '];
  $date = date('m-d-y h:i:sa');
  $reason = "Medicine";
 
  $paymentmethod = $_POST['paymentmethod'];
  $test_id = $_SESSION['Test_id'];
  $docsuggestion = $_POST['docsug'];
  $patientid = $_SESSION['patient_id '];
  $Prescriptionid = $_SESSION['prescriptionid'];
  $medicinename = $_POST['selectm'];
 
  $day = $_POST['day'];
  $perday = $_POST['perday'];
  $pilsamount = $day * $perday;



  
// calculate price




// add pdrescription

$sql3 = "SELECT Remain_Amount, Dos FROM medicine_price_db WHERE Medicine_Name = '$medicinename'";
$re = mysqli_query($conn, $sql3);
foreach($re as $row){
  $remain = $row['Remain_Amount'];
  $dosage = $row['Dos'];
  $description = "$medicinename, $dosage For $day Days";
}
if($remain > 0){

if($remain >= $pilsamount){


$sql = "INSERT INTO prescription_db (Patient_id, Medicine_name, Dose, Days, Per_Day, Doctor_id,  Date) 
Values ('$patientid', '$medicinename', '$dosage', '$day', $perday, '$user_id', '$date')";
$result1 = mysqli_query($conn, $sql);
if ($result1) {
$Prescription_id = mysqli_insert_id($conn);
$_SESSION['prescriptionid'] = $Prescription_id;
}
$sql = " SELECT Price, Quantity, Sold_Amount, Remain_Amount FROM medicine_price_db 
WHERE Medicine_Name = '$medicinename' AND Dos = '$dosage'";
$result = mysqli_query($conn, $sql);

if ($result) {
foreach ($result as $row) {
  $price = $row['Price'];
  
  $quantity = $row['Quantity'];
  $_SESSION['pr'] = $quantity;
  $soldamount = $row['Sold_Amount'];
  $remainamount = $row['Remain_Amount'];
}
}


$totalprice = $price * $pilsamount;
$soldamount = $soldamount + $pilsamount;
$remainamount = $quantity - $soldamount;
$_SESSION['price'] = $price;
$_SESSION['quantity'] =  $pilsamount;
$_SESSION['totalprice'] = $totalprice;



if($remainamount > 0){
  $sql1 = " UPDATE medicine_price_db SET Sold_Amount = $soldamount, Remain_Amount =  $remainamount
  WHERE Medicine_Name = '$medicinename' AND Dos = '$dosage'";
  $result1 = mysqli_query($conn, $sql1);
  }
  else{
    $sql1 = "DELETE FROM medicine_price_db WHERE $remainamount <= 0 ";
    $result1 = mysqli_query($conn, $sql1);
  }

if ($paymentmethod == "Cash") {
$sql = "INSERT INTO bill (Patient_id, Quantity,Reason, Description, Unit_Price, Total_Price , Payment_Method, Date) Values (?,?,?,?,?,?,?,?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssss", $patientid, $pilsamount, $reason, $description, $price, $totalprice, $paymentmethod, $date);
$stmt->execute();
} else {
$sql = "INSERT INTO insurance_db (Patient_id, Quantity,Reason, Description, Unit_Price, Total_Price , Payment_Method, Date) Values (?,?,?,?,?,?,?,?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssss", $patientid, $pilsamount, $reason, $description, $price, $totalprice, $paymentmethod, $date);
$stmt->execute();
}


$sql = " SELECT * FROM diagnosis_db WHERE Prescription_id IS NULL AND Patient_id = '$patientid' AND Test_id = $test_id  ";
  $re = mysqli_query($conn, $sql);
  if ($re->num_rows > 0) {
    $sql1 = "UPDATE diagnosis_db SET Doctor_Suggestion = '$docsuggestion', Prescription_id = '$Prescriptionid' WHERE 
   Patient_id = '$patientid' AND Test_id = '$test_id'  ";
    $result1 = mysqli_query($conn, $sql1);
    if ($result1) {
      $_SESSION['status'] = " Prescription Added Successfully";
      $_SESSION['status_code'] = "success";
      header("Location:../../fields/Doctor/AddPrescriptionForm.php?Test_id=$test_id?addSymptom=success");

    } else {
      echo "Error";
    }
  } else {
    $sql01 = " SELECT * FROM diagnosis_db WHERE Patient_id = '$patientid' AND Test_id = $test_id ";
    $res = mysqli_query($conn, $sql01);
    $ro = mysqli_fetch_assoc($res);
    $age = $ro['Age'];
    $finding = $ro['Finding'];
    $symptom = $ro['Symptoms'];
    $docsuggestion = $ro['Doctor_Suggestion'];
    $doctor_id = $ro['Doctor_id'];
    $date = $ro['Date'];
    $sql = "INSERT INTO diagnosis_db (Patient_id,  Age, Finding, Symptoms, Test_id, Doctor_Suggestion, Prescription_id, Doctor_id, Date) VALUES 
  ('$patientid', '$age', '$finding',  '$symptom', '$test_id', '$docsuggestion', '$Prescriptionid', '$doctor_id', '$date')";
    $result2 = mysqli_query($conn, $sql);
    if ($result2) {
      $_SESSION['status'] = " Prescription Added Successfully";
      $_SESSION['status_code'] = "success";
      header("Location:../../fields/Doctor/AddPrescriptionForm.php?Test_id=$test_id?addSymptom=success");
    } else {
      echo "Error";
    }
  }
}else{
  $_SESSION['status'] = "Unavailable pils Amount Please Try Again ";
  $_SESSION['status_code'] = "error";
  header("Location:../../fields/Doctor/AddPrescriptionForm.php?Test_id=$test_id?addPrescription=error");
}
}


  $sql1 = " SELECT Price FROM test_price_db WHERE Test_Type = '$testType'";
  $result3 = mysqli_query($conn, $sql1);
  if ($result3) {
    foreach ($result3 as $row) {
      $price = $row['Price'];
    }
  }







?>
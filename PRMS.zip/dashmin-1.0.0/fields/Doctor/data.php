<?php
require 'Connection.php';
if(isset($_POST['stdnm'])){
    $mn = $_POST['stdnm'];
    $sql2 = "SELECT Dos FROM medicine_price_db WHERE Medicine_Name = '$mn'";
    $result2 = $conn->query($sql2);
    $row = $result2->fetch_assoc();
    echo json_encode($row);
  }

  ?>
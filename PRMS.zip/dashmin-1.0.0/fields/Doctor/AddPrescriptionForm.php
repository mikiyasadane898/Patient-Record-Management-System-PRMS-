<?php
require 'Connection.php';

$sql1 = "SELECT * FROM medicine_price_db";
$result1 = $conn->query($sql1);


?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <title>DASHMIN - Bootstrap Admin Template</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta content="" name="keywords" />
  <meta content="" name="description" />

  <!-- Favicon -->
  <link href="img/favicon.ico" rel="icon" />

  <!-- Google Web Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet" />

  <!-- Icon Font Stylesheet -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />

  <!-- Libraries Stylesheet -->
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />
  <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

  <!-- Customized Bootstrap Stylesheet -->
  <link href="css/bootstrap.min.css" rel="stylesheet" />

  <!-- Template Stylesheet -->
  <link href="css/style.css" rel="stylesheet" />
  <script src="js/sweetalert.min.js"></script>
 
  <script>
    function submitForm(form) {
      swal({
          title: "are you sure",
          Text: "this form will be submitted",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((isOkay) => {
          if (isOkay) {
            form.submit();
          }
        });
      return false;
    }
  </script>
</head>

<body>
  <div class="container-xxl position-relative bg-white d-flex p-0">
    <!-- Spinner Start -->
    <?php
    include 'header.php';
    ?>
    <!-- Navbar End -->

    <!-- patient info Start -->
    <div class="container-fluid pt-4 px-4">
      <div class="row g-4">
        <div class="col-sm-12 col-xl-12">
          <div class="bg-light rounded h-100 p-4">
          <div class="text-end">
            <a href="../../fields/Doctor/ViewResult.php" class="nav-link ">
              <button type="button" class="btn btn-outline-primary m-2 float-end">save </button>
            </a>
          </div>
          <h6 class="mb-4">Patient Information</h6>
            <?php

            require 'Connection.php';
            require 'Doctor.php';

            $data1 = selectTestID();
            while ($row = $data1->fetch_assoc()) {
              echo '<label for="Patient ID" class="col-sm-2">Patient ID</label>';
              echo '<lable id = "Patient ID" class="col-sm-6">' . $row["Patient_id"] . '</label>' . '<br>';
              echo '<label for="FirstName" class="col-sm-2">FirstName</label>';
              echo '<lable id = "FirstName" class="col-sm-6">' . $row["FirstName"] . '</label>' . '<br>';
              echo '<label for="MiddleName" class="col-sm-2">MiddleName</label>';
              echo '<lable id = "MiddleName" class="col-sm-6">' . $row["MiddleName"] . '</label>' . '<br>';
              echo '<label for="LastName" class="col-sm-2">LastName</label>';
              echo '<lable id = "LastName" class="col-sm-6">' . $row["LastName"] . '</label>' . '<br>';
              echo '<label for="Age" class="col-sm-2">Age</label>';
              echo '<lable id = "Age" class="col-sm-6">' . $row["Age"] . '</label>' . '<br>';
              echo '<label for="Sex" class="col-sm-2">Sex</label>';
              echo '<lable id = "Sex" class="col-sm-6">' . $row["Sex"] . '</label>' . '<br>';
              echo '<label for="Date" class="col-sm-2">Date</label>';
              echo '<lable id = "Date" class="col-sm-6">' . $row["Date"] . '</label>' . '<br>';
              echo '<label for="Date" class="col-sm-2">Test ID</label>';
              echo '<lable id = "Date" class="col-sm-6">' . $row['Test_id'] . '</label>' . '<br>';

              $_SESSION['Test_id'] = $row['Test_id'];
              $_SESSION['Patient_id'] = $row['Patient_id'];
            }


            ?>
          </div>
        </div>
      </div>
    </div>
    <!-- view patient info End -->
    <!-- form start -->
    <form action="AddPrescription.php" method="POST" onsubmit="return submitForm(this);">
      <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
          <div class="col-sm-12 col-xl-12">
            <div class="bg-light rounded h-100 p-4">
              <h6 class="mb-4">Doctor Suggesion</h6>
              <div class="form-floating">
                <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea" style="height: 150px" name="docsug"></textarea>
                <label for="floatingTextarea">suggesion</label>

              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- form end -->
      <!-- input fields side by side -->

      <div class="container-fluid pt-10">
        <div class="row h-100" style="min-height: 100vh">
          <div class="col-6 col-sm-8 col-md-6 col-lg-12 col-xl-12">
            <div class="bg-light rounded p-4 p-sm-5 my-4 mx-3">
              <div class="d-flex align-items-center justify-content-between mb-10">
                <a href="viewprescription.html" class="">
                  <h6 class="text-primary"></h6>
                </a>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-floating mb-3">
                    
                    <select class="form-control" id="floatingText" name="selectm" id= "medk">
                    
                      <?php
                      foreach ($result1 as $row) {
                        echo "<option value = '" . $row['Medicine_Name'] . "'   name= 'med'>" . $row['Medicine_Name'].' ' . $row['Dos'] .  "</option>";
                        
                      }

                      ?>
                    </select>
                    <label for="floatingText">Select Medicine</label>
                    
                  </div>
                </div>
               
                <div class="col-md-6">
                  <div class="form-floating mb-3">
                    <input type="number" class="form-control" id="floatingText3" placeholder="jhondoe" name="day" />
                    <label for="floatingText3">Day</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-floating mb-3">
                    <input type="number" class="form-control" id="floatingText4" placeholder="jhondoe" name="perday" />
                    <label for="floatingText4">Per Day</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-floating mb-3">
                    <select class="form-control" id="floatingText" name="paymentmethod">
                      <option value="Cash">Cash</option>
                      <option value="Insurace">Insurace </option>
                    </select>
                    <label for="floatingText">Select Payment Method</label>
                  </div>
                </div>
              </div>
              <button type="submit" class="btn btn-primary py-3 w-100 mb-4" name="addprescription"> SAVE</button>
              <?php
                $n = $_SESSION['Patient_id'];
                echo '<a href="Result.php?patient_id=' . $n . '" class="btn btn-primary py-3 w-100 mb-4">CANCEL</a>';
                ?>
            </div>
          </div>
        </div>
      </div>

    </form>
    <!-- input fields side by side -->



    <!-- Footer Start -->
    <footer>
      <span class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
          <div class="row">
            <div class="col-12 col-sm-6 text-center text-sm-start">
              &copy; Copyright 2024 <label style="color: #009CFF;"> MDBSB</label>. All Right Reserved.
            </div>

          </div>
        </div>
      </span>
    </footer>
    <!-- Footer End -->

  <!-- Content End -->

  <!-- Back to Top -->
  <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
  </div>

  <!-- JavaScript Libraries -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="lib/chart/chart.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/tempusdominus/js/moment.min.js"></script>
  <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
  <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
  <script src="js/sweetalert.min.js"></script>


  <?php
  if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
  ?>
    <script>
      swal({
        title: '<?php echo $_SESSION['status']; ?>',
        text: '<?php echo $_SESSION['status_code']; ?>',
        icon: "success",
        button: "Okay!",
      });
    </script>
  <?php
    unset($_SESSION['status']);
  }
  ?>
  <!-- Template Javascript -->
  <script src="js/main.js"></script>
 
</body>

</html>
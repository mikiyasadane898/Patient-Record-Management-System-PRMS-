<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <title>DASHMIN - Bootstrap Admin Template</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta content="" name="keywords" />
  <meta content="" name="description" />

  <!-- Favicon -->
  <link href="img/favicon.ico" rel="icon" />

  <!-- Google Web Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet" />

  <!-- Icon Font Stylesheet -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />

  <!-- Libraries Stylesheet -->
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />
  <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

  <!-- Customized Bootstrap Stylesheet -->
  <link href="css/bootstrap.min.css" rel="stylesheet" />

  <!-- Template Stylesheet -->
  <link href="css/style.css" rel="stylesheet" />
</head>

<body>
  <?php
  include('header.php');
  ?>

  <!-- patient info Start -->
  <div class="container-fluid pt-4 px-4">
    <div class="row g-4">
      <div class="col-sm-12 col-xl-12">
        <div class="bg-light rounded h-100 p-4">
          <?php

          require 'Connection.php';
          require 'Doctor.php';

          $data1 = selectPatientName();
          while ($row = $data1->fetch_assoc()) {
            echo '<label for="Patient ID" class="col-sm-2">Patient ID</label>';
            echo '<lable id = "Patient ID" class="col-sm-6">' . $row["Patient_id"] . '</label>' . '<br>';
            echo '<label for="FirstName" class="col-sm-2">FirstName</label>';
            echo '<lable id = "FirstName" class="col-sm-6">' . $row["FirstName"] . '</label>' . '<br>';
            echo '<label for="MiddleName" class="col-sm-2">MiddleName</label>';
            echo '<lable id = "MiddleName" class="col-sm-6">' . $row["MiddleName"] . '</label>' . '<br>';
            echo '<label for="LastName" class="col-sm-2">LastName</label>';
            echo '<lable id = "LastName" class="col-sm-6">' . $row["LastName"] . '</label>' . '<br>';
            echo '<label for="Age" class="col-sm-2">Age</label>';
            echo '<lable id = "Age" class="col-sm-6">' . $row["Age"] . '</label>' . '<br>';
            echo '<label for="Sex" class="col-sm-2">Sex</label>';
            echo '<lable id = "Sex" class="col-sm-6">' . $row["Sex"] . '</label>' . '<br>';

            $_SESSION['patient_id '] = $row["Patient_id"];
          }


          ?>

        </div>

      </div>
    </div>
  </div>
  <!-- view patient info End -->


  <!-- Patient info End -->
  <div class="container-fluid pt-4 px-4">
    <div class="col-sm-12 col-xl-12">
      <div class="bg-light rounded h-100 p-4">
        <h6 class="mb-4">Test</h6>
        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
          <li class="nav-item" role="presentation">
            <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-homee" type="button" role="tab" aria-controls="pills-home" aria-selected="true">
              Test Type
            </button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profilee" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">
              Result
            </button>
          </li>
        </ul>
        <div class="tab-content" id="pills-tabContent">
          <div class="tab-pane fade show active" id="pills-homee" role="tabpanel" aria-labelledby="pills-home-tab">

            <div class="container-fluid pt-2 px-2">
              <div class="bg-light text-center rounded p-2">
                <div class="table-responsive">
                  <?php
                  require 'Connection.php';
                  $data1 = selectPatient();
                  if ($data1->num_rows > 0) {
                  ?>

                    <table class="table text-start align-middle table-bordered table-hover mb-0">
                      <thead>
                        <tr class="text-dark">
                          <th scope="row">Date</th>
                          <th scope="row">Test ID</th>
                          <th scope="row">Clinical Diagnosis</th>
                          <th scope="col">Test Type</th>
                          <th scope="col">Requested Test</th>

                        </tr>
                      </thead>
                      <tbody>
                      <?php
                      foreach ($data1 as $row) {

                        echo '<tr>';
                        echo '<td>' . $row["Date"]  . '</td>';
                        echo '<td>' . $row["Test_id"]  . '</td>';
                        echo '<td>' . $row["Clinical_Diagnosis"] . '</td>';
                        echo '<td>' . $row["Test_Type"] . '</td>';
                        echo '<td>' . $row["Requested_Test"] . '</td>';
                        echo '</tr>';

                        $_SESSION['test_id'] =  $row["Test_id"];
                      }
                    }

                      ?>
                      </tbody>
                    </table>
                    </table>
                </div>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="pills-profilee" role="tabpanel" aria-labelledby="pills-profile-tab">
            <div class="container-fluid pt-2 px-2">
              <div class="bg-light text-center rounded p-2">
                <div class="table-responsive">
                  <?php
                  require 'Connection.php';
                  $data1 = selectPatient();
                  if ($data1->num_rows > 0) {
                  ?>
                    <table class="table text-start align-middle table-bordered table-hover mb-0">
                      <thead>
                        <tr class="text-dark">
                          <th scope="row">Test Result</th>
                          <th scope="col">Test Done BY</th>
                          <th scope="col">Add Prescription</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                      foreach ($data1 as $row) {
                        echo '<tr>';
                        echo '<td>' . $row["Test_Result"]  . '</td>';
                        echo '<td>' . $row["Professional_id"]  . '</td>';
                        echo "<form action='AddPrescriptionForm.php' method='POST'>";
                        echo "<input type='hidden' name='patient_id' value=" . $row["Patient_id"] . ">";
                        $_SESSION['patient_id'] = $row["Patient_id"];

                        echo "<input type='hidden' name='t_id' value=" . $row["Test_id"] . ">";
                        echo '<td>' . "<a type ='submit' class='btn btn-sm btn-primary' href= 'AddPrescriptionForm.php?Test_id=" . $row["Test_id"] . "'>Add Prescription<a/>" . '</td>';
                        echo '</tr>';
                      }
                    }

                      ?>
                      </tbody>
                    </table>
                    </table>

                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>


    <!-- Footer Start -->
    <footer>
      <span class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
          <div class="row">
            <div class="col-12 col-sm-6 text-center text-sm-start">
              &copy; Copyright 2024 <label style="color: #009CFF;"> MDBSB</label>. All Right Reserved.
            </div>

          </div>
        </div>
      </span>
    </footer>
    <!-- Footer End -->

    <!-- Content End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
  </div>

  <!-- JavaScript Libraries -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="lib/chart/chart.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/tempusdominus/js/moment.min.js"></script>
  <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
  <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
  <script src="js/sweetalert.min.js"></script>

  <?php
  if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
  ?>
    <script>
      swal({
        title: '<?php echo $_SESSION['status']; ?>',
        text: '<?php echo $_SESSION['status_code']; ?>',
        icon: "success",
        button: "Okay!",
      });
    </script>
  <?php
    unset($_SESSION['status']);
  }
  ?>
  <!-- Template Javascript -->
  <script src="js/main.js"></script>
</body>

</html>
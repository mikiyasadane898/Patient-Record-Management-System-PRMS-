<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <title>Eka Kotebe managment system</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta content="" name="keywords" />
  <meta content="" name="description" />

  <!-- Favicon -->
  <link href="img/favicon.ico" rel="icon" />

  <!-- Google Web Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet" />

  <!-- Icon Font Stylesheet -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />

  <!-- Libraries Stylesheet -->
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />
  <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

  <!-- Customized Bootstrap Stylesheet -->
  <link href="css/bootstrap.min.css" rel="stylesheet" />

  <!-- Template Stylesheet -->
  <link href="css/style.css" rel="stylesheet" />

  <script>
    function showUser(str) {

      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          document.getElementById("table-view").innerHTML = this.responseText;
        }
      };
      xmlhttp.open("GET", "Search.php/search()?q=" + str, true);
      xmlhttp.send();
    }
  </script>
</head>

<body>
  <?php
  include('header.php');
  ?>

  <!-- view patient table Start -->
  <div class="container-fluid pt-4 px-4" id="table-view">
    <div class="bg-light text-center rounded p-4">
      <div class="d-flex align-items-center justify-content-between mb-4">
        <h6 class="mb-0"></h6>
        <a href="">Show All</a>
      </div>
      <div class="table-responsive">
        <?php
        include 'Connection.php';
        require 'Doctor.php';

        $result = SelectPatientSelectForDoctorFromDatabase();
        
            if (mysqli_multi_query($conn, $result)) {
                  
                    // Store first result sget
                    if ($result = mysqli_store_result($conn)) {
                     if($result -> num_rows >0){
                      ?>
                      <table class="table text-start align-middle table-bordered table-hover mb-0">
                        <thead>
                          <tr class="text-dark">
                            <th scope="col">Patient ID</th>
                            <th scope="col">First Name</th>
                            <th scope="col">Middle Name</th>
                            <th scope="col">Last Name</th>
                            <th scope="col">Sex</th>
                            <th scope="col">Age</th>
                            <th scope="col">Date</th>
                            <th scope="col">View</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php
                      
                      while ($row = $result->fetch_row()) {
                ?>
                        <tr>
                          <td><?php printf("%s\n", $row[0]); ?></td>
                          <td><?php printf("%s\n", $row[1]); ?></td>
                          <td><?php printf("%s\n", $row[2]); ?></td>
                          <td><?php printf("%s\n", $row[3]); ?></td>
                          <td><?php printf("%s\n", $row[4]); ?></td>
                          <td><?php printf("%s\n", $row[5]); ?></td>
                          <td><?php printf("%s\n", $row[6]); ?></td>
                          
                          <?php
                          echo "<form action='AddTestForm.php' method='POST'>";
                      echo "<input type='hidden' name='patient_id' value=" . $row[0] . ">";
                      echo '<td>' . "<a type ='submit' class='btn btn-outline-primary mb-2' href= 'AddTestForm.php?patient_id=" . $row[0] . "'>View <a/>" . '</td>';
                      echo "</form>";
                      ?>
                        </tr>

                <?php
                      }
                      $result->free_result();
                    }else{
                      echo "No Record";
                     
                    }
    
                    // if there are more result-sets, the print a divider
                    //if (mysqli_more_results($conn)) {
                    // 
                    // }
                    //Prepare next result set
                   
                while ( mysqli_next_result($conn));
                  }
                mysqli_close($conn);
              }
                ?>
            </tbody>
          </table>
      </div>
    </div>
  </div>
  <!-- view patient table End -->

  <!-- Footer Start -->
  <footer>
    <span class="container-fluid pt-4 px-4">
      <div class="bg-light rounded-top p-4">
        <div class="row">
          <div class="col-12 col-sm-6 text-center text-sm-start">
            &copy; Copyright 2024 <label style="color: #009CFF;"> MDBSB</label>. All Right Reserved.
          </div>

        </div>
      </div>
    </span>
  </footer>
  <!-- Footer End -->
  
  <!-- Content End -->

  <!-- Back to Top -->
  <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
  </div>

  <!-- JavaScript Libraries -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="lib/chart/chart.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/tempusdominus/js/moment.min.js"></script>
  <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
  <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
  <script src="js/sweetalert.min.js"></script>

  <?php
  if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
  ?>
    <script>
      swal({
        title: '<?php echo $_SESSION['status']; ?>',
        text: '<?php echo $_SESSION['status_code']; ?>',
        icon: "success",
        button: "Okay!",
      });
    </script>
  <?php
    unset($_SESSION['status']);
  }
  ?>
  <!-- Template Javascript -->
  <script src="js/main.js"></script>
</body>

</html>
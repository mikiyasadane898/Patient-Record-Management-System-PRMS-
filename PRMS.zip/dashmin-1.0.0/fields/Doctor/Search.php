<?php

search();
function search()
{ session_start();


  $q = $_GET['q'];

  require 'Connection.php';


  $user_id = $_SESSION['user_id'];
  $sql = "SELECT  p.*, u.User_id, d.* FROM
  patient_db p
  JOIN diagnosis_db d ON p.Patient_id = d.Patient_id
  JOIN user_db u ON u.User_id = d.Doctor_id
  where d.Doctor_id = '$user_id' AND d.Symptoms IS NULL AND d.Patient_id = '$q'";
  $result =  mysqli_query($conn, $sql);

?>

 
    <div class="container-fluid pt-4 px-4">

      <div class="bg-light text-center rounded p-4">
        <div class="table-responsive" id="table-view">
        <?php
           
            if($result ->num_rows > 0){
          ?>
          <table class="table text-start align-middle table-bordered table-hover mb-0">
            <thead>
              <tr class="text-dark">
                <th scope="col">Patien ID</th>
                <th scope="col">Fname</th>
                <th scope="col">Mname</th>
                <th scope="col">Lname</th>
                <th scope="col">Age</th>
                <th scope="col">Sex</th>
                <th scope="col">Phone Number</th>
                <th scope="col">Address</th>
                <th scope="col">Date</th>
                <th scope="col">view</th>
              </tr>
            </thead>
            <tbody>
              <?php

              while ($row = mysqli_fetch_array($result)) {


                echo '<tr>';
                echo '<td>' . $row["Patient_id"] . '</td>';
                echo '<td>' . $row["FirstName"] . '</td>';
                echo '<td>' . $row["MiddleName"] . '</td>';
                echo '<td>' . $row["LastName"] . '</td>';
                echo '<td>' . $row["Sex"] . '</td>';
                echo '<td>' . $row["Age"] . '</td>';
                echo '<td>' . $row["PhoneNumber"] . '</td>';
                echo '<td>' . $row["Address"] . '</td>';
                echo '<td>' . $row["Date"] . '</td>';
                echo "<form action='AddTest.php' method='POST'>";
                echo "<input type='hidden' name='patient_id' value=" . $row["Patient_id"] . ">";
                echo '<td>' . "<a type ='submit' class='btn btn-sm btn-primary' href= 'AddTest.php?patient_id=" . $row["Patient_id"] . "'>View <a/>" . '</td>';
                echo "</form>";
                echo "</td>";
                echo '</tr>';

                $_SESSION['Patient_id'] = $row["Patient_id"];
                echo '</table>';
                ?>
                <?php
              }
            }
            else
            {
              echo "No Record";
            }


              
              ?>


            </tbody>
          </table>

        </div>
      </div>
    </div>

<?php

  mysqli_close($conn);
}

?>
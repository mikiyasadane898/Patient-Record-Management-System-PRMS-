<?php
date_default_timezone_set('Africa/Nairobi');

  session_start();

  require 'Connection.php';



  $clinicalDiagnosis = $_POST['lclinicaldiagnosis'];
  $testType = $_POST['selectlt'];
  $testName = $_POST['ltestname'];
  $patientid = $_SESSION['ip'];
  $date = date('m-d-y h:i:sa');
  $user_id = $_SESSION['user_id'];
  $description =  " For $testType Test ";
  $reason = "Test";
  $paymentmethod = $_POST['lpaymentmethod'];
  $quantity = "1";
  
  $symptom = $_POST['symptoms'];
  $date = date('m-d-y h:i:sa');


  

  $sql = "INSERT INTO test_db (Patient_id, Clinical_Diagnosis, Test_type, Requested_Test, Doctor_id, Date) 
    Values ('$patientid', '$clinicalDiagnosis', '$testType',  '$testName', '$user_id', '$date')";
  $result = mysqli_query($conn, $sql);
  

  if ($result) {
    $Test_id = mysqli_insert_id($conn);
    $_SESSION['tid'] = $Test_id;
    $_SESSION['status'] = " Test and Symptoms Added Successfully";
    $_SESSION['status_code'] = "success";
    header("Location:../../fields/Doctor/AddTestForm.php?patient_id=$patientid?addTest=success");
  } else {
    $_SESSION['status'] = " Test and Symptoms Not Added  Successfully";
    $_SESSION['status_code'] = "error";
    header("Location:../../fields/Doctor/AddTestForm.php?patient_id=$patientid?addTest=error");
  }
  $T_id = $_SESSION['tid'];

  $sql = " SELECT * FROM diagnosis_db WHERE Symptoms IS NULL AND Patient_id = '$patientid' ";
  $re = mysqli_query($conn, $sql);
  if ($re->num_rows > 0) {
    $sql1 = "UPDATE diagnosis_db SET Symptoms = '$symptom' , Test_id = '$T_id' 
  WHERE Patient_id = '$patientid' AND Symptoms IS NULL  ";
    $result1 = mysqli_query($conn, $sql1);
    if ($result1) {

      header("Location:../../fields/Doctor/AddTestForm.php?patient_id=$patientid?addSymptom=success");
    } else {
      echo "Error";
    }
  } else {
    $age = $_SESSION['age'];
    $finding = $_SESSION['finding'];
    $doctor_id = $_SESSION['user_id'];
    $sql = "INSERT INTO diagnosis_db (Patient_id,  Age, Finding, Symptoms, Test_id, Doctor_id, Date) VALUES 
  ('$patientid', '$age', '$finding',  '$symptom', '$T_id', '$doctor_id', '$date')";
    $result2 = mysqli_query($conn, $sql);
    if ($result2) {

      header("Location:../../fields/Doctor/AddTestForm.php?patient_id=$patientid?addSymptom=success");
    } else {
      echo "Error";
    }
  }


  $sql1 = " SELECT Price FROM test_price_db WHERE Test_Type = '$testType'";
  $result3 = mysqli_query($conn, $sql1);
  if ($result3) {
    foreach ($result3 as $row) {
      $price = $row['Price'];
    }
  }

  if ($paymentmethod == "Cash") {
    $sql = "INSERT INTO bill (Patient_id, Quantity,Reason, Description, Unit_Price, Total_Price , Payment_Method, Date) Values (?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $patientid, $quantity, $reason, $description, $price, $price, $paymentmethod, $date);
    $stmt->execute();
  } else {
    $sql = "INSERT INTO insurance_db (Patient_id, Quantity,Reason, Description, Unit_Price, Total_Price , Payment_Method, Date) Values (?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $patientid, $quantity, $reason, $description, $price, $price, $paymentmethod, $date);
    $stmt->execute();
  }



?>
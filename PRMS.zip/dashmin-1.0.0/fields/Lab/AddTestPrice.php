<?php
  session_start();
  require 'Connection.php';

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $testname = $_POST['testname'];
  $price = $_POST['price'];
  $date = $_POST['date'];
  $added_by = ($_SESSION['FirstName'] . ' ' . $_SESSION['MiddleName']);

  $sql = "INSERT INTO test_price_db (Test_Type, Price, Added_By, Date) VALUES ('$testname', '$price', '$added_by','$date')";

  $result = mysqli_query($conn, $sql);

  if ($result) {
    $_SESSION['status'] = " Test Added Successfully";
        $_SESSION['status_code'] = "success";
    header("Location:viewTest.php?adding=success");
  } else{
    $_SESSION['status'] = " Test Not Added Successfully";
        $_SESSION['status_code'] = "Error";
    header("Location:AddTestPriceForm.php?adding=error");
  }


?>
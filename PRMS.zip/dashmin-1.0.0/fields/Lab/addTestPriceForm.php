<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <title>DASHMIN - Bootstrap Admin Template</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta content="" name="keywords" />
  <meta content="" name="description" />
  <script src="sweetalert.min.js"></script>
  <script>
    function submitForm(form) {
      swal({
          title: "are you sure",
          Text: "this form will be submitted",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((isOkay) => {
          if (isOkay) {
            form.submit();
          }
        });
      return false;
    }
  </script>
  <?php
  include 'script.php';
  ?>
</head>

<body>
  <div class="container-xxl position-relative bg-white d-flex p-0">
    <!-- Spinner Start -->
    <?php
    include 'header.php';
    ?>


    <!-- input fields side by side -->
    <form action="AddTestPrice.php" method="POST" onsubmit="return submitForm(this);">
      <div class="container-fluid pt-10">
        <div class="row h-100" style="min-height: 100vh">
          <div class="col-6 col-sm-8 col-md-6 col-lg-12 col-xl-12">
            <div class="bg-light rounded p-4 p-sm-5 my-4 mx-3">
              <div class="d-flex align-items-center justify-content-between mb-10">
                <h6 class="text-primary">Add Test</h6>
              </div>
              <div class="col">
                <div class="col-md-6">
                  <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="floatingText1" placeholder="jhondoe" name="testname" />
                    <label for="floatingText1">Test Type</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="floatingText2" placeholder="jhondoe" name="price" />
                    <label for="floatingText2">Price</label>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-floating mb-3">
                    <input type="Date" class="form-control" id="floatingText3" placeholder="jhondoe" name="date" />
                    <label for="floatingText3">Date</label>
                  </div>
                </div>

              </div>

              <button type="submit" class="btn btn-primary py-3 w-25 mb-4" name="Add"> ADD</button>
              <button type="submit" class="btn btn-primary py-3 w-25 mb-4" name="calcel">CANCEL</button>

            </div>
          </div>
        </div>
      </div>

    </form>
    <!-- input fields side by side -->



    <!-- Footer Start -->
    <footer>
      <span class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
          <div class="row">
            <div class="col-12 col-sm-6 text-center text-sm-start">
              &copy; Copyright 2024 <label style="color: #009CFF;"> MDBSB</label>. All Right Reserved.
            </div>

          </div>
        </div>
      </span>
    </footer>
    <!-- Footer End -->
  </div>
  <!-- Content End -->

  <!-- Back to Top -->
  <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
  </div>

  <!-- JavaScript Libraries -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="lib/chart/chart.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/tempusdominus/js/moment.min.js"></script>
  <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
  <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

  <!-- Template Javascript -->
  <script src="js/main.js"></script>
</body>

</html>
<?php

session_start();
require 'Connection.php';

$result1 = $_POST['Result'];
$tid = $_SESSION['test_id'];
$pid = $_SESSION['patient_id '];
$uid = $_SESSION['user_id'];


$sql = " UPDATE test_db SET Test_Result = '$result1', Professional_id = '$uid'  WHERE Patient_id = '$pid' AND Test_id = '$tid' ";

$result = mysqli_query($conn, $sql);


  if ($result) {
   
    $_SESSION['status'] = " Result Added Successfully";
    $_SESSION['status_code'] = "success";
    header("Location:ViewLabTest.php?addResult=success");
  } else {
    $_SESSION['status'] = " Result Not Added  Successfully";
    $_SESSION['status_code'] = "error";
    header("Location:AddResultForm.php?addResult=error");
  }
?>
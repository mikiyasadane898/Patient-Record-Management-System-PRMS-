<?php
session_start();

  require 'Connection.php';
  date_default_timezone_set('Africa/Nairobi');
  $test_type = $_POST['Test_Type'];
  $price = $_POST['Price'];
  $added_by = $_POST['Added_By'];
  $date = date('m-d-y h:i:sa');
  $sql = "UPDATE test_price_db  SET   Price = '$price',  LastUpdatedDate = '$date',
  Added_By = '$added_by'  WHERE Test_Type = '$test_type' ";
  $result = mysqli_query($conn, $sql);
  if ($result) {
    $_SESSION['status'] = " Test Edited Successfully";
        $_SESSION['status_code'] = "success";
        header("Location: viewTest.php?update=success");
    
  } else
   {
    $_SESSION['status'] = " Test Not Added Successfully";
        $_SESSION['status_code'] = "Error";
    header("Location:editTestPriceForm.php?updating=error");
   }


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <title>Eka kotebe(PMS)</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta content="" name="keywords" />
  <meta content="" name="description" />

  <!-- Favicon -->
  <link href="img/favicon.ico" rel="icon" />

  <!-- Google Web Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet" />

  <!-- Icon Font Stylesheet -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />

  <!-- Libraries Stylesheet -->
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />
  <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

  <!-- Customized Bootstrap Stylesheet -->
  <link href="css/bootstrap.min.css" rel="stylesheet" />

  <!-- Template Stylesheet -->
  <link href="css/style.css" rel="stylesheet" />
</head>

<body>
  <div class="container-xxl position-relative bg-white d-flex p-0">
    <!-- Spinner Start -->
    <?php
    include 'header.php'
    ?>
    <!-- Spinner Start -->


    <!-- Typography Start -->
    <div class="container-fluid pt-4 px-4">
      <div class="row g-4">
        <div class="col-sm-12 col-xl-12">
          <div class="bg-light rounded h-100 p-4">
            <?php

            require 'Connection.php';
            require 'Laboratorian.php';

            $data1 = selectPatientName();
            while ($row = $data1->fetch_assoc()) {
              echo '<label for="Patient ID" class="col-sm-2">Patient ID</label>';
              echo '<lable id = "Patient ID" class="col-sm-6">' . $row["Patient_id"] . '</label>' . '<br>';
              echo '<label for="FirstName" class="col-sm-2">FirstName</label>';
              echo '<lable id = "FirstName" class="col-sm-6">' . $row["FirstName"] . '</label>' . '<br>';
              echo '<label for="MiddleName" class="col-sm-2">MiddleName</label>';
              echo '<lable id = "MiddleName" class="col-sm-6">' . $row["MiddleName"] . '</label>' . '<br>';
              echo '<label for="LastName" class="col-sm-2">LastName</label>';
              echo '<lable id = "LastName" class="col-sm-6">' . $row["LastName"] . '</label>' . '<br>';
              echo '<label for="Age" class="col-sm-2">Age</label>';
              echo '<lable id = "Age" class="col-sm-6">' . $row["Age"] . '</label>' . '<br>';
              echo '<label for="Sex" class="col-sm-2">Sex</label>';
              echo '<lable id = "Sex" class="col-sm-6">' . $row["Sex"] . '</label>' . '<br>';
              $_SESSION['patient_id '] = $row["Patient_id"];
            }


            ?>

          </div>

        </div>
      </div>
    </div>



    <!-- Typography Start -->
    <div class="container-fluid pt-4 px-4">
      <div class="row g-4">
        <div class="col-sm-12 col-xl-12">
          <div class="bg-light rounded h-100 p-4">
            <h3>Test Information</h3>
            <?php

            $data1 = selectTestDetail();
            while ($row = $data1->fetch_assoc()) {
              echo '<label for="Date" class="col-sm-2">Date</label>';
              echo '<lable id = "Date" class="col-sm-6">' . $row["Date"] . '</label>' . '<br>';
              echo '<label for="Test ID" class="col-sm-2">Test ID</label>';
              echo '<lable id = "Test ID" class="col-sm-6">' . $row["Test_id"] . '</label>' . '<br>';
              echo '<label for="Clinical Diagnosis" class="col-sm-2">Clinical Diagnosis</label>';
              echo '<lable id = "Clinical_Diagnosis" class="col-sm-6">' . $row["Clinical_Diagnosis"] . '</label>' . '<br>';
              echo '<label for="Test Type" class="col-sm-2">Test Type</label>';
              echo '<lable id = "Test Type" class="col-sm-6">' . $row["Test_Type"] . '</label>' . '<br>';
              echo '<label for="Requested Test" class="col-sm-2">Requested Test</label>';
              echo '<lable id = "Requested Test" class="col-sm-6">' . $row["Requested_Test"] . '</label>' . '<br>';

              $_SESSION['patient_id '] = $row["Patient_id"];
              $_SESSION['test_id'] = $row["Test_id"];
            }


            ?>

          </div>

        </div>
      </div>
    </div>

    <!-- Typography End -->

    <!-- form start -->
    <form action="AddResult.php" method="POST" onsubmit="return submitForm(this);">
      <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
          <div class="col-sm-12 col-xl-12">
            <div class="bg-light rounded h-100 p-4">
              <h6 class="mb-4">Result</h6>
              <div class="form-floating">
                <textarea class="form-control" id="floatingTextarea" style="height: 150px" name="Result"></textarea>
                <label for="floatingTextarea">Result</label>

              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- form end -->

      <!-- input fields side by side -->

      <div class="container-fluid pt-10">

        <div class="row h-100" style="min-height: 100vh">
          <div class="col-6 col-sm-8 col-md-6 col-lg-12 col-xl-12">
            <div class="bg-light rounded p-4 p-sm-5 my-4 mx-3">
              <div class="d-flex align-items-center justify-content-between mb-10">
                <a href="" class="">
                  <h6 class="text-primary"></h6>
                </a>
              </div>
              <div class="row">
                <button type="submit" class="btn btn-primary py-3 w-100 mb-4" name="Save">SAVE</button>
                <a href="../Lab/ViewLabTest.php" class="btn btn-primary py-3 w-100 mb-4">CANCEL</a>
              </div>
            </div>
          </div>
        </div>
    </form>
    <!-- input fields side by side -->

    <!-- Footer Start -->
    <footer>
      <span class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
          <div class="row">
            <div class="col-12 col-sm-6 text-center text-sm-start">
              &copy; Copyright 2024 <label style="color: #009CFF;"> MDBSB</label>. All Right Reserved.
            </div>

          </div>
        </div>
      </span>
    </footer>
    <!-- Footer End -->
  </div>
  <!-- Content End -->

  <!-- Back to Top -->
  <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
  </div>

  <!-- JavaScript Libraries -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="lib/chart/chart.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/tempusdominus/js/moment.min.js"></script>
  <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
  <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

  <!-- Template Javascript -->
  <script src="js/main.js"></script>
</body>

</html>
<?php


require 'Connection.php';
if (isset($_POST["Save"])) {
  addResultToDatabase();
}

if (isset($_POST["Add"])) {
  AddTestPrice();
}
if (isset($_POST["update_test"])) {
  editTest()();
}
function addResultToDatabase()
{
  session_start();
  require 'Connection.php';

  $result1 = $_POST['Result'];
  $tid = $_SESSION['test_id'];
  $pid = $_SESSION['patient_id '];
  $uid = $_SESSION['user_id'];


  $sql = " UPDATE test_db SET Test_Result = '$result1', Professional_id = '$uid'  WHERE Patient_id = '$pid' AND Test_id = '$tid' ";

  $result = mysqli_query($conn, $sql);


    if ($result) {
     
      $_SESSION['status'] = " Result Added Successfully";
      $_SESSION['status_code'] = "success";
      header("Location:ViewLabTest.php?addResult=success");
    } else {
      $_SESSION['status'] = " Result Not Added  Successfully";
      $_SESSION['status_code'] = "error";
      header("Location:update.php?addResult=error");
    }
}




function selectTestFromDatabase()
{

  require 'Connection.php';
  // SQL query to fetch data from the "myTable" table
  $sql1 = " SELECT DISTINCT(d.Age), p.Patient_id, p.FirstName, p.MiddleName, p.LastName, p.Sex, t.Date, t.Test_id FROM 
      patient_db p INNER JOIN test_db t ON p.Patient_id = t.Patient_id 
      INNER JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
      JOIN bill b ON p.Patient_id = b.Patient_id
      WHERE t.Test_Result IS NULL AND t.Test_Type != 'ULTRASOUND' 
      AND t.Test_Type != 'X-RAY' AND t.Test_Type != 'MRI' AND t.Test_Type != 'CT-SCAN' 
      AND t.Test_Type != 'ECHO' AND d.Doctor_Suggestion IS null AND  b.Receipt_Number IS NOT NULL AND b.Reason = 'Test';
      SELECT DISTINCT(d.Age), p.Patient_id, p.FirstName, p.MiddleName, p.LastName, p.Sex, t.Date, t.Test_id FROM 
      patient_db p INNER JOIN test_db t ON p.Patient_id = t.Patient_id 
      INNER JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
      JOIN insurance_db i ON p.Patient_id = i.Patient_id
      WHERE t.Test_Result IS NULL AND t.Test_Type != 'ULTRASOUND' 
      AND t.Test_Type != 'X-RAY' AND t.Test_Type != 'MRI' AND t.Test_Type != 'CT-SCAN' 
      AND t.Test_Type != 'ECHO' AND d.Doctor_Suggestion IS null AND  i.Insurance_code IS NOT NULL AND i.Reason = 'Test' ";
  
    return $sql1;
  
}



function selectPatientName()
{


  require 'Connection.php';
  $patientid = $_POST['patient_id'];

  $sql = " SELECT DISTINCT(d.Age), p.Patient_id, p.FirstName, p.MiddleName, p.LastName, p.Sex
  FROM patient_db p INNER JOIN test_db t ON p.Patient_id = t.Patient_id 
  INNER JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
  WHERE t.Test_Result IS NULL AND t.Test_Type != 'ULTRASOUND' 
  AND t.Test_Type != 'X-RAY' AND t.Test_Type != 'MRI' AND
   t.Test_Type != 'CT-SCAN' AND t.Test_Type != 'ECHO' AND 
   d.Doctor_Suggestion IS null AND p.Patient_id = '$patientid '";

  $result = mysqli_query($conn, $sql);

  return $result;
}

function selectTestDetail()
{


  require 'Connection.php';
  $patientid = $_POST['patient_id'];
  $test_id = $_POST['test_id'];

  $sql = " SELECT DISTINCT * FROM test_db WHERE Patient_id = '$patientid' and Test_id = '$test_id' ";

  $result = mysqli_query($conn, $sql);

  return $result;
}



function SelectTestPrice()
{

  require 'Connection.php';

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // SQL query to fetch data from the "myTable" table
  $sql = "SELECT * From test_price_db";
  $result = $conn->query($sql);

  return $result;
}


function AddTestPrice()
{
  session_start();
  require 'Connection.php';

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $testname = $_POST['testname'];
  $price = $_POST['price'];
  $date = $_POST['date'];
  $added_by = ($_SESSION['FirstName'] . ' ' . $_SESSION['MiddleName']);

  $sql = "INSERT INTO test_price_db (Test_Type, Price, Added_By, Date) VALUES ('$testname', '$price', '$added_by','$date')";

  $result = mysqli_query($conn, $sql);

  if ($result) {
    header("Location:ViewTest.php?error=success");
  } else
    echo "error";
}

function editTest()
{

  require 'Connection.php';
  date_default_timezone_set('Africa/Nairobi');
  $test_type = $_POST['Test_Type'];
  $price = $_POST['Price'];
  $added_by = $_POST['Added_By'];
  $date = date('m-d-y h:i:sa');
  $sql = "UPDATE test_price_db  SET 
  Price = '$price',
  LastUpdatedDate = '$date',
  Added_By = '$added_by'
  WHERE Test_Type = '$test_type' ";
  $result = mysqli_query($conn, $sql);
  if ($result) {
    header("Location:ViewTest.php?error=success");
  } else
    echo "error";
}

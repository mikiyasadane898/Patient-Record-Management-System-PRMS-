<?php

search();
function search()
{ session_start();


  $q = $_GET['q'];

  require 'Connection.php';


  $user_id = $_SESSION['user_id'];
  $sql = "SELECT p.*, t.* FROM
  patient_db p   INNER JOIN test_db t ON p.Patient_id = t.Patient_id
  WHERE t.Test_Result = '' AND t.Test_Type != 'ULTRASOUND' AND t.Test_Type != 'X-RAY' 
  AND t.Test_Type != 'MRI' AND t.Test_Type != 'CT-SCAN'
  AND t.Test_Type != 'ECHO'  AND p.Patient_id = '$q'";
  $result =  mysqli_query($conn, $sql);

?>

 
    <div class="container-fluid pt-4 px-4">

      <div class="bg-light text-center rounded p-4">
        <div class="table-responsive" id="table-view">
        <?php
           
            if($result ->num_rows > 0){
          ?>
          <table class="table text-start align-middle table-bordered table-hover mb-0">
            <thead>
              <tr class="text-dark">
              <th scope="row">Patient ID</th>
                  <th scope="row">First Name</th>
                  <th scope="col">Middle Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col">Age</th>
                  <th scope="col">Sex</th>
                  <th scope="row">Date</th>
                  <th scope="row">View</th>
              </tr>
            </thead>
            <tbody>
              <?php

              while ($row = mysqli_fetch_array($result)) {


                echo '<tr>';
                echo '<td>' . $row["Patient_id"] . '</td>';
                echo '<td>' . $row["FirstName"] . '</td>';
                echo '<td>' . $row["MiddleName"] . '</td>';
                echo '<td>' . $row["LastName"] . '</td>';
                echo '<td>' . $row["Age"] . '</td>';
                echo '<td>' . $row["Sex"] . '</td>';
                echo '<td>' . $row["Date"] . '</td>';
                echo "<form action='Update.php' method='POST'>";
                echo "<input type='hidden' name='patient_id' value=" . $row["Patient_id"] . ">";
                echo "<input type='hidden' name='test_id' value=" . $row["Test_id"] . ">";
                echo  '<td>' . "<button type='submit' class='btn btn-sm btn-primary' >View</button>" . '</td>';

                echo "</form>";

                echo '</tr>';
                
                ?>
                <?php
              }
            }
            else
            {
              echo "No Record";
            }


              
              ?>


            </tbody>
          </table>

        </div>
      </div>
    </div>

<?php

  mysqli_close($conn);
}

?>
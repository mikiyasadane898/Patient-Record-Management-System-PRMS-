<?php
session_start();
require 'Connection.php';

    $id = $_POST['testtype'];

    $query = "DELETE FROM test_price_db WHERE Test_Type = '$id'";
    $query_run = mysqli_query($conn, $query);
    if ($query_run) {
        $_SESSION['status'] = " Test Deleted Successfully";
        $_SESSION['status_code'] = "success";
        header("Location: viewTest.php?update=success");
      } else {
        $_SESSION['status'] = " Test Not Deletes  Successfully";
        $_SESSION['status_code'] = "error";
        header("Location: viewTest.php?update=error");
      }
   


?>
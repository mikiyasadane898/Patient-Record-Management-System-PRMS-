
<?php

    session_start();
    date_default_timezone_set('Africa/Nairobi');
  
      require 'Connection.php';
     
      $medicineid = $_POST['Medicine_Name'];
      $quantity = $_POST['Quantity'];
      $price = $_POST['Price'];
      $added_by = $_POST['Added_By'];
      $date = date('m-d-y h:i:sa');
      $sql = "UPDATE medicine_price_db  SET Quantity = '$quantity', Price = '$price', LastUpdatedDate = '$date',
         Added_By = '$added_by' WHERE Medicine_Name = '$medicineid' ";
      $result = mysqli_query($conn, $sql);
      if($result){
        header("Location:ViewMedicine.php?login=success");}
        else
        echo "error";
    
    
    
  

  ?>
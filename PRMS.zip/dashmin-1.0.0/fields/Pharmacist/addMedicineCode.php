<?php
 session_start();
 date_default_timezone_set('Africa/Nairobi');

   
   
    require 'Connection.php';
    $date = date('m-d-y h:i:sa');
    $uid = $_SESSION['FirstName']. ' '. $_SESSION['MiddleName'];
    $medicinename = $_POST['medicinename'];
    $dos = $_POST['dosage'];
    $quantity = $_POST['quantity'];
    $remainamount = $_POST['quantity'];
    $price = $_POST['price'];
    $date = date('m-d-y h:i:sa');
    
$sql2 = "SELECT Medicine_Name FROM medicine_price_db WHERE Medicine_Name = '$medicinename'  ";
$result2 = mysqli_query($conn, $sql2);

if($result2 -> num_rows >0){
  $_SESSION['status'] = " Exist Medicine Please Edit the Existing One  ";
        $_SESSION['status_code'] = "error";
      header("Location:addMedicine.php?login=success");
}{



    $sql = "INSERT INTO  medicine_price_db (Medicine_Name, Dos, Quantity,Remain_Amount, Price, Added_By, Date)
    VALUE ( '$medicinename','$dos', '$quantity', $remainamount, '$price', '$uid', '$date') ";
  
    $result = mysqli_query($conn, $sql);
  
    if($result){
        $_SESSION['status'] = " Medicine Added Successfully";
        $_SESSION['status_code'] = "success";
      header("Location:ViewMedicine.php?login=success");}
      else
      echo "error";
    }

  ?>
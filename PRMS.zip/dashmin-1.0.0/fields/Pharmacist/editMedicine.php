<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Eka Kotebe managment system</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <script src="js/sweetalert.min.js"></script>
    
  <script>
    function submitForm(form) {
      
      swal({
          title: "Are You Sure ?",
          Text: "this form will be submitted",
          icon: "warning",
          buttons: [true, "Yes"],
          dangerMode: true,
        })
        .then((isOkay) => {
          if (isOkay) {
            form.submit();
          }
        });
      return false;
    }
  </script>

</head>

<body>

    <div class="container-xxl position-relative bg-white d-flex p-0">
    <?php  require 'header.php'; ?>
       

        <!-- Sign Up Start -->
        <div class="container-fluid">
            <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
                <div class="row-6 row-sm-8 row-md-6 row-lg-12 row-xl-10">
                    <div class="bg-light rounded p-4 p-sm-5 my-4 mx-3">

                        <form action="EditMedicineCode.php" method="POST" onsubmit="return submitForm(this);">
                            <div class="d-flex align-items-center justify-content-between mb-10">
                               
                                    <h6 class="text-primary"></i>EDIT USER</h6>
                                
                            </div>
                            <div class="row">

                                <?php
                                require 'Connection.php';
                                if (isset($_GET['Medicine_Name'])) {
                                    $Medicine_id = $_GET['Medicine_Name'];
                                   

                                    $sql = "SELECT * FROM medicine_price_db WHERE Medicine_Name = '$Medicine_id' ";
                                    $result = mysqli_query($conn, $sql);

                                    if (mysqli_num_rows($result) > 0) {
                                        foreach ($result as $row) {
                                        }
                                ?>

                                        
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="Medicine_Name" value="<?= $row['Medicine_Name']; ?>" readonly>
                                                <label for="floatingText">Medicine Name</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="Dos" value="<?= $row['Dos']; ?>">
                                                <label for="floatingText">Dos</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="Quantity" value="<?= $row['Quantity']; ?>">
                                                <label for="floatingText">Quantity</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="Price" value="<?= $row['Price']; ?>" >
                                                <label for="floatingText">Price</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="Added_By" value="<?= $row['Added_By']; ?>" readonly>
                                                <label for="floatingText">Added_By</label>
                                            </div>
                                        </div>
                                        


                            </div>

                            <div class="text-center">
                                <button type="submit" name="update_med" class="btn btn-primary py-3 w-50 mb-4 ">APPLY</button>
                                <a type="submit" class="btn btn-primary py-3 w-50 mb-4" name="calcel" href="../Pharmacist/ViewMedicine.php">CANCEL</a>
                            </div>

                        </form>
                    <?php
                                    } else {


                    ?>
                        <h4>No Record Found</h4>
                <?php
                                    }
                                }
                ?>


                    </div>
                </div>
            </div>
        </div>

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="lib/chart/chart.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/tempusdominus/js/moment.min.js"></script>
        <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
        <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
</body>

</html>
<?php

if(isset($_POST['Save'])){
  savePrescription();
}

if(isset($_POST['update_med'])){
  updateMedicine();
}

function selectPatient()
{

  require 'Connection.php';

  $sql1 = "SELECT DISTINCT p.Patient_id, p.FirstName, p.MiddleName, p.LastName, d.Age, p.Sex 
  FROM  patient_db p INNER JOIN prescription_db pr ON p.Patient_id = pr.Patient_id 
   INNER JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
   INNER JOIN bill b ON p.Patient_id = b.Patient_id 
  WHERE pr.Pharmacist_id IS NULL AND b.Receipt_Number IS NOT NULL AND b.Reason = 'Medicine';
  SELECT DISTINCT p.Patient_id, p.FirstName, p.MiddleName, p.LastName, d.Age, p.Sex
  FROM  patient_db p INNER JOIN prescription_db pr ON p.Patient_id = pr.Patient_id 
   INNER JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
   INNER JOIN insurance_db i ON p.Patient_id = i.Patient_id 
  WHERE pr.Pharmacist_id IS NULL AND i.Insurance_code IS NOT NULL AND i.Reason = 'Medicine';";
  

  return $sql1;
}

function selectPatientname() {
    
  require 'Connection.php';
$pid = $_SESSION['patient_id'];
  $sql1 = "SELECT DISTINCT p.Patient_id, p.FirstName, p.MiddleName, p.LastName, d.Age, p.Sex
  FROM patient_db p 
  INNER JOIN prescription_db pr ON p.Patient_id = pr.Patient_id
  INNER JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
  WHERE p.Patient_id = '$pid' ";
  $result = $conn->query($sql1);
 
    return $result;
}
  
function SelectPrescription()
{
  require 'Connection.php';
  
  $patientid = $_SESSION['patient_id'];
  $sql = " SELECT p.*, u.User_id, u.FirstName, u.MiddleName FROM prescription_db p
  INNER JOIN user_db u ON p.Doctor_id = u.User_id
  WHERE p.Patient_id = '$patientid' AND p.Pharmacist_id IS NULL";
  // Execute the SQL statement
  $result = $conn->query($sql);


  return $result;
}



function savePrescription(){
  session_start();
  require 'Connection.php';

  $uid = $_SESSION['FirstName']. ' '. $_SESSION['MiddleName'];
  $pid = $_POST['Prescription_id'];
  $sql = "UPDATE prescription_db SET Pharmacist_id = '$uid' 
  WHERE Prescription_id = '$pid' ";

  $result = mysqli_query($conn, $sql);

    if ($result) {
      $data = SelectPrescription();
      if($data -> num_rows > 0){
      $_SESSION['status'] = " Prescription Saved Successfully";
      $_SESSION['status_code'] = "success";
      header("Location:view.php?addprescription=sucess");
    } else {
      $_SESSION['status'] = " Prescription Saved Successfully";
      $_SESSION['status_code'] = "success";
      header("Location:viewprescription.php?addprescription=sucess");
    }
}else{
  $_SESSION['status'] = " Prescription Not Saved Successfully";
      $_SESSION['status_code'] = "error";
      header("Location:view.php?addprescription=Error");
}
}






function selectMedicine(){

  require 'Connection.php';

  $sql = " SELECT * FROM medicine_price_db";
  $result = mysqli_query($conn, $sql); 
  return $result;
  
}


function updateMedicine() {

  session_start();
  date_default_timezone_set('Africa/Nairobi');

    require 'Connection.php';
   
    $medicineid = $_POST['Medicine_Name'];
    $quantity = $_POST['Quantity'];
    $price = $_POST['Price'];
    $added_by = $_POST['Added_By'];
    $date = date('m-d-y h:i:sa');
    $sql = "UPDATE medicine_price_db  SET 
    Quantity = '$quantity',
    Price = '$price',
    LastUpdatedDate = '$date',
    Added_By = '$added_by'
    WHERE Medicine_Name = '$medicineid ' ";
    $result = mysqli_query($conn, $sql);
    if($result){
      header("Location:ViewMedicine.php?login=success");}
      else
      echo "error";
  
  
  
}




?>
<?php
session_start();
require 'Connection.php';

$Role = $_POST["Role"];
// $user_id = $_POST["id"];
$Fname = $_POST["Fname"];
$_SESSION['fname'] = $Fname;
$Mname = $_POST["Mname"];
$_SESSION['Mname']= $Mname;
$Lname = $_POST["Lname"];
$_SESSION['Lname']= $Mname;
$Age = $_POST["Age"];
$_SESSION['Age']= $Mname;
$Sex = $_POST["Sex"];
$_SESSION['Sex']= $Mname;
$Speciality = $_POST["Speciality"];
$_SESSION['Speciality']= $Mname;
$Pnumber = $_POST["Pnumber"];
$_SESSION['Pnumber']= $Mname;
$Address = $_POST["Address"];
$_SESSION['Address']= $Mname;
$User_name = $_POST["User_name"];
$_SESSION['User_name']= $Mname;
$pass = $_POST["Password"];
$_SESSION['Password']= $Mname;
$hashed_password = password_hash($pass, PASSWORD_BCRYPT);

$Password = $hashed_password;
$Date = date('m-d-y h:i:sa');



if ($_FILES["image"]["error"] === 4) {
  header("Location:AddUser.php?error=wronguser");
} else {
  $filename = $_FILES["image"]["name"];
  $filesize = $_FILES["image"]["size"];
  $tmpName = $_FILES["image"]["tmp_name"];

  $validImageExtension = ['jpg', 'jpeg', 'png'];
  $imageExtension = explode('.', $filename);
  $imageExtension = strtolower(end($imageExtension));
  if (!in_array($imageExtension, $validImageExtension)) {
    echo "<script> alert('Invalid Image Extension');</script>";
  } elseif ($filesize > 1000000000) {
    echo "<script> alert('big image size');</script>";
  } else {
    $newImageName = uniqid();
    $newImageName .= '.' . $imageExtension;

    move_uploaded_file($tmpName, '../../i/' . $filename);
    $_SESSION['image'] = $filename;
  }



  $sqlu = "SELECT Username FROM user_db WHERE Username = '$User_name'";
  $uresult = mysqli_query($conn, $sqlu);

  $query = "SELECT Password FROM user_db";
  $resultp = $conn->query($query);
  $hashed_passwords = array();
  while ($row = $resultp->fetch_assoc()) {
    $hashed_passwords[] = $row['Password'];
  }

  if ($hashed_passwords) {
    foreach ($hashed_passwords as $hashed_password) {
      $h = $hashed_password;
      if (password_verify($pass, $h)) {
        $_SESSION['h'] = "match";
      }
    }
  }




  if ($uresult->num_rows > 0) {
    $_SESSION['status'] = " Duplicated UserName please Try Again";
    $_SESSION['status_code'] = "Error";
    header("Location: AddUserForm.php?AddUser=error");
  } elseif (isset($_SESSION['h'])) {
    $_SESSION['status'] = " Duplicated Password please Try Again";
    $_SESSION['status_code'] = "Error";
    header("Location: AddUserForm.php?AddUser=error");
    unset($_SESSION['h']);
  } else {

    $sql = "INSERT INTO user_db ( FirstName, MiddleName, LastName, Sex, Age, Username, Password, Role, Specialty, PhoneNumber,Address, ProfilePicture, Date ) Values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssissssisss", $Fname, $Mname, $Lname, $Sex, $Age, $User_name, $Password, $Role, $Speciality, $Pnumber, $Address, $filename, $Date);
    $stmt->execute();
    header("Location:ViewUser.php?login=success");
    if ($stmt) {
      $_SESSION['status'] = " User Added Successfully";
      $_SESSION['status_code'] = "success";
      header("Location: ../../fields/admin/ViewUser.php?update=success");
    } else {
      $_SESSION['status'] = " User Not Added  Successfully";
      $_SESSION['status_code'] = "error";
      header("Location: AddUserForm.php?update=error");
    }

    $stmt->close();
    $conn->close();
  }
}

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <title>DASHMIN - Bootstrap Admin Template</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta content="" name="keywords" />
  <meta content="" name="description" />
  <?php
  require 'script.php';

  ?>
  <style>
        footer {
    
    left: 0;
    bottom: 0;
    width: 100%;
    margin-top: 0;
    color: #333;
    padding: 0;
    text-align: center;
}

    </style>
</head>

<body>
  <?php
  include 'header and sidebar.php';
  ?>

  <!-- Recent Sales Start -->
  <div class="container-fluid pt-4 px-4">
    <div class="bg-light text-center rounded p-4">
      <div class="d-flex align-items-center justify-content-between mb-4">

        <h6 class="mb-0">Login History</h6>
        <a href="allLoginHistory.php">Show All</a>

      </div>
      <div class="table-responsive">
        <table class="table text-start align-middle table-bordered table-hover mb-0">
          <thead>
            <tr class="text-dark">
              <th scope="col">User ID</th>
              <th scope="col">User Name</th>
              <th scope="col">Login Time</th>
              <th scope="col">Login Time</th>
              <th scope="col">Day</th>
              <th scope="col">Date</th>
            </tr>
          </thead>
          <tbody>
            <?php
            require 'Connection.php';
            require 'Admin.php';
            $data = SelectLoginHistoryFromDatabase();

            foreach ($data as $row) {
              echo '<tr>';
              echo '<td>' . $row["User_id"] . '</td>';
              echo '<td>' . $row["User_name"] . '</td>';
              echo '<td>' . $row["Login_Time"] . '</td>';
              echo '<td>' . $row["Logout_Time"] . '</td>';
              echo '<td>' . $row["Day"] . '</td>';
              echo '<td>' . $row["Date"] . '</td>';
              echo '</tr>';
            }
            echo '</table>';

            ?>

          </tbody>
        </table>
      </div>
    </div>
  </div>
  <!-- Recent Sales End -->

  <!-- Footer Start -->
  <footer>
        <span class="container-fluid pt-4 px-4">
            <div class="bg-light rounded-top p-4">
                <div class="row">
                    <div class="col-12 col-sm-6 text-center text-sm-start" >
                    &copy; Copyright 2024 <label style="color: #009CFF;"> MDBSB</label>. All Right Reserved.
                    </div>
                    
                </div>
            </div>
          </span>
         </footer>
  <!-- Footer End -->
  </div>
  <!-- Content End -->

  <!-- Back to Top -->
  <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
  </div>

  <!-- JavaScript Libraries -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="lib/chart/chart.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/tempusdominus/js/moment.min.js"></script>
  <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
  <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
  <script src="js/sweetalert.min.js"></script>
  <!-- Template Javascript -->
  <script src="js/main.js"></script>
</body>

</html>
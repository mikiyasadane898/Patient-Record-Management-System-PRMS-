<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Eka Kotebe managment system</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <script src="js/sweetalert.min.js"></script>
    <script type="text/javascript">
        function preventBack() {
            window.history.forward()
        };
        setTimeout("preventBack()", 0);
        window.onunload = function() {
            null;
        }
    </script>
    <script >
       function submitForm(form){
        swal({
            title: "are you sure",
            Text: "this form will be submitted",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((isOkay) =>{
            if(isOkay){
                form.submit();
            }
        });
        return false;
       }
    </script>
    
    <?php
    require 'script.php';
    require 'Connection.php';
    ?>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sign Up Start -->
        <div class="container-fluid">
            <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
                <div class="col-6 col-sm-8 col-md-6 col-lg-12 col-xl-10">
                    <div class="bg-light rounded p-4 p-sm-5 my-4 mx-3">

                        <form action="EditSubmit.php" method="POST" onsubmit="return submitForm(this);">
                            <div class="d-flex align-items-center justify-content-between mb-10">
                                <a href="index.html" class="">
                                    <h6 class="text-primary"></i>EDIT USER</h6>
                                </a>
                            </div>
                            <div class="row">

                                <?php
                                if (isset($_GET['User_id'])) {
                                    $user_id = $_GET['User_id'];
                                    $sql = "SELECT * FROM user_db WHERE User_id = '$user_id' ";
                                    $result = mysqli_query($conn, $sql);

                                    if (mysqli_num_rows($result) > 0) {
                                        foreach ($result as $row) {
                                        }
                                ?>

                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="User_id" value="<?= $row['User_id']; ?>" readonly>
                                                <label for="floatingText">User Id</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="FirstName" value="<?= $row['FirstName']; ?>">
                                                <label for="floatingText">FirstName</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="MiddleName" value="<?= $row['MiddleName']; ?>">
                                                <label for="floatingText">MiddleName</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="LastName" value="<?= $row['LastName']; ?>">
                                                <label for="floatingText">LastName</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="Age" value="<?= $row['Age']; ?>">
                                                <label for="floatingText">Age</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <select name="Sex" class="form-control" id="floatingText">
                                                    <option value="Male" <?= $row['Sex'] == "Male" ? "Selected" : ""; ?>>Male</option>
                                                    <option value="Female" <?= $row['Sex'] == "Female" ? "Selected" : ""; ?>>Female</option>
                                                </select>
                                                <label for="floatingText">Sex</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <select name="Role" required class="form-control" id="floatingText">
                                                    <option value="">Select Role</option>
                                                    <option value="Administrator" <?= $row['Role'] == "Administrator" ? "Selected" : ""; ?>>Administrator</option>
                                                    <option value="Doctor" <?= $row['Role'] == "Doctor" ? "Selected" : ""; ?>>Doctor</option>
                                                    <option value="Reception" <?= $row['Role'] == "Reception" ? "Selected" : ""; ?>>Reception</option>
                                                    <option value="Pharmacist" <?= $row['Role'] == "Pharmacist" ? "Selected" : ""; ?>>Pharmacist</option>
                                                    <option value="Laboratorian" <?= $row['Role'] == "Laboratorian" ? "Selected" : ""; ?>>Laboratorian</option>
                                                    <option value="Radiology" <?= $row['Role'] == "Radiology" ? "Selected" : ""; ?>>Radiology</option>
                                                    <option value="Sonographer" <?= $row['Role'] == "Sonographer" ? "Selected" : ""; ?>>Sonographer</option>
                                                    <option value="Cashier" <?= $row['Role'] == "Cashier" ? "Selected" : ""; ?>>Cashier</option>
                                                </select>
                                                <label for="floatingText">Rol</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="Specialty" value="<?= $row['Specialty']; ?>">
                                                <label for="floatingText">Speciality</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="PhoneNumber" value="<?= $row['PhoneNumber']; ?>">
                                                <label for="floatingText">PhoneNumber</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="Address" value="<?= $row['Address']; ?>">
                                                <label for="floatingText">Address</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-3">
                                                <input type="text" class="form-control" id="floatingText" name="Username" value="<?= $row['Username']; ?>">
                                                <label for="floatingText">User Name</label>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-floating mb-4 ">
                                                <input type="text " class="form-control" id="floatingPassword" name="Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
                                                <label for="floatingText">Password</label>
                                            </div>
                                        </div>

                            </div>

                            <div class="text-center">
                                <button type="submit" name="update_user" class="btn btn-primary py-3 w-50 mb-4 ">APPLY</button>
                                <a type="submit" name="cancel" class="btn btn-primary py-3 w-50 mb-4 " href="ViewUser.php">Cancel</a>
                            </div>

                        </form>
                    <?php
                                    } else {


                    ?>
                        <h4>No Record Found</h4>
                <?php
                                    }
                                }
                ?>


                    </div>
                </div>
            </div>
        </div>
        

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="lib/chart/chart.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/tempusdominus/js/moment.min.js"></script>
        <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
        <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
        <script src="js/sweetalert.min.js"></script>
        <!-- Template Javascript -->
        <script src="js/main.js"></script>
        
    
    <?php
    if(isset($_SESSION['status']) && $_SESSION['status'] != ''){
    ?>
    <script>
        swal({
            title: '<?php echo $_SESSION['status'];?>',
            text: '<?php echo $_SESSION['status_code'];?>',
            icon: "error",
            button: "Okay!",
        });
    </script>
    <?php
    unset($_SESSION['status']);
}
?>
</body>

</html>
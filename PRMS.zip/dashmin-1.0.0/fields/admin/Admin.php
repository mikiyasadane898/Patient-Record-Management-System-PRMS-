<?php


require 'Connection.php';
if (!$conn) {
  die("Connection failed! :" . mysqli_connect_error());
} else {


  SelectUserFromDatabase();
  SelectLoginHistoryFromDatabase();
  SelectLoginHistoryall();
  //selectDetailPatientReport();
}

if (isset($_POST['update_user'])) {
  EditUser();
}

if (isset($_POST['submit'])) {
  addUser();
}



function addUser()
{
  session_start();
  require 'Connection.php';

  $Role = $_POST["Role"];
  // $user_id = $_POST["id"];
  $Fname = $_POST["Fname"];
  $Mname = $_POST["Mname"];
  $Lname = $_POST["Lname"];
  $Age = $_POST["Age"];
  $Sex = $_POST["Sex"];
  $Speciality = $_POST["Speciality"];
  $Pnumber = $_POST["Pnumber"];
  $Address = $_POST["Address"];
  $User_name = $_POST["User_name"];
  $Password = $_POST["Password"];
  $Date = date('m-d-y h:i:sa');



  if ($_FILES["image"]["error"] === 4) {
    header("Location:AddUser.php?error=wronguser");
  } else {
    $filename = $_FILES["image"]["name"];
    $filesize = $_FILES["image"]["size"];
    $tmpName = $_FILES["image"]["tmp_name"];

    $validImageExtension = ['jpg', 'jpeg', 'png'];
    $imageExtension = explode('.', $filename);
    $imageExtension = strtolower(end($imageExtension));
    if (!in_array($imageExtension, $validImageExtension)) {
      echo "<script> alert('Invalid Image Extension');</script>";
    } elseif ($filesize > 1000000000) {
      echo "<script> alert('big image size');</script>";
    } else {
      $newImageName = uniqid();
      $newImageName .= '.' . $imageExtension;

      move_uploaded_file($tmpName, '../../i/' . $filename);
    }


    $sql = "INSERT INTO user_db ( FirstName, MiddleName, LastName, Sex, Age, Username, Password, Role, Specialty, PhoneNumber,Address, ProfilePicture, Date ) Values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssissssisss", $Fname, $Mname, $Lname, $Sex, $Age, $User_name, $Password, $Role, $Speciality, $Pnumber, $Address, $filename, $Date);
    $stmt->execute();
    header("Location:ViewUser.php?login=success");
    if ($stmt) {
      $_SESSION['status'] = " User Added Successfully";
      $_SESSION['status_code'] = "success";
      header("Location: ../../fields/admin/ViewUser.php?update=success");
    } else {
      $_SESSION['status'] = " User Not Added  Successfully";
      $_SESSION['status_code'] = "error";
      header("Location: AddUser.php?update=error");
    }

    $stmt->close();
    $conn->close();
  }
}


function SelectUserFromDatabase()
{
  require 'Connection.php';


  $sql = "SELECT * From user_db ";
  $result = $conn->query($sql);

  return   $result;
}

function EditUser()
{
  session_start();


  require 'Connection.php';

  

    $Role = $_POST["Role"];
    $user_id = $_POST["User_id"];
    $Fname = $_POST["FirstName"];
    $Mname = $_POST["MiddleName"];
    $Lname = $_POST["LastName"];
    $Age = $_POST["Age"];
    $Sex = $_POST["Sex"];
    $Speciality = $_POST["Specialty"];
    $Pnumber = $_POST["PhoneNumber"];
    $Address = $_POST["Address"];
    $User_name = $_POST["Username"];
    $Password = $_POST["Password"];
    $Date = date('m-d-y h:i:sa');

    $sql = " UPDATE user_db SET FirstName='$Fname', MiddleName='$Mname', LastName='$Lname', Age='$Age', Sex='$Sex', Specialty='$Speciality', 
  Role='$Role', PhoneNumber='$Pnumber', Address='$Address', Username='$User_name', Password='$Password', LastUpdatedDate='$Date'
  WHERE User_id = '$user_id' ";

    $result = mysqli_query($conn, $sql);

    if ($result) {
      $_SESSION['status'] = " Updated Successfully";
      $_SESSION['status_code'] = "success";
      header("Location: ../../fields/admin/ViewUser.php?update=success");
    } else {
      $_SESSION['status'] = "Not Updated Successfully";
      $_SESSION['status_code'] = "error";
      header("Location: Edituser.php?update=error");
    }
  }


if (isset($_POST['delete'])) {
  deleteUser();
}

function deleteUser()
{

  require 'Connection.php';

  $uid = $_POST['user_id'];

  $sql = "DELETE FROM user_db WHERE User_id = '$uid'";
  $result = mysqli_query($conn, $sql);

  if ($result) {
    header("Location: ViewUser.php?login=success");
  } else
    echo "error";
}


function selectPatientReport()
{

  require 'Connection.php';

  $sql = "SELECT DISTINCT EXTRACT(YEAR FROM Date) AS year, EXTRACT(MONTH FROM Date) AS month FROM diagnosis_db ORDER BY year";
  $result = mysqli_query($conn, $sql);

 
  return $result;
}

function  selectDetailPatientReport()
{

  require 'Connection.php';

  $y = $_POST['datey'];
  $m = $_POST['datem'];
  

  $sql = "SELECT COUNT(d.Age) as age FROM diagnosis_db d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age < 5 AND p.Sex = 'Male' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m'); 
  SELECT COUNT(d.Age) as age1 FROM diagnosis_db d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age < 5 AND p.Sex = 'Female' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m');
  SELECT COUNT(d.Age) as age2 FROM `diagnosis_db` d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age >= 5 and d.Age <= 10 AND p.Sex = 'Male' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m'); 
   SELECT COUNT(d.Age) as age3 FROM `diagnosis_db` d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age >= 5  and d.Age <= 10 AND p.Sex = 'Female' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m'); 
   SELECT COUNT(d.Age) as age4 FROM `diagnosis_db` d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age > 10 and d.Age <=19  AND p.Sex = 'Male' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m');
   SELECT COUNT(d.Age) as age5 FROM `diagnosis_db` d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age >10  and d.Age <=19 AND p.Sex = 'Female' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m'); 
  SELECT COUNT(d.Age) as age6 FROM `diagnosis_db` d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age > 10 and d.Age <=19  AND p.Sex = 'Male' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m');
   SELECT COUNT(d.Age) as age7 FROM `diagnosis_db` d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age >19  and d.Age <=29 AND p.Sex = 'Female' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m');
  SELECT COUNT(d.Age) as age8 FROM `diagnosis_db` d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age > 29 and d.Age <=45   AND p.Sex = 'Male' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m'); 
  SELECT COUNT(d.Age) as age9 FROM `diagnosis_db` d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age >29  and d.Age <=45 AND p.Sex = 'Female' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m'); 
  SELECT COUNT(d.Age) as age10 FROM `diagnosis_db` d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age > 45 and d.Age <=65   AND p.Sex = 'Male' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m');
  SELECT COUNT(d.Age) as age11 FROM `diagnosis_db` d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age >45  and d.Age <=65 AND p.Sex = 'Female' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m');
   SELECT COUNT(d.Age) as age12 FROM `diagnosis_db` d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age > 65  AND p.Sex = 'Male' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m');
  SELECT COUNT(d.Age) as age13 FROM `diagnosis_db` d INNER JOIN
  patient_db p on p.Patient_id = d.Patient_id WHERE d.Age > 65   AND p.Sex = 'Female' 
  AND  (YEAR(d.Date) = '$y') AND (MONTH(d.Date) = '$m') ";
  
  return $sql;
  

}


function selectBillInsuranceall()
{
  require 'Connection.php';

  $sql = " SELECT * FROM insurance_db ";

  $result = mysqli_query($conn, $sql);
  return $result;
}


function selectBillInsuranceDetail()
{
  require 'Connection.php';

  $sql = " SELECT * FROM insurance_db LIMIT 5 ";

  $result = mysqli_query($conn, $sql);
  return $result;
}

function selectBillCashDetail()
{
  require 'Connection.php';

  $sql = " SELECT * FROM bill  LIMIT 5";

  $result = mysqli_query($conn, $sql);
  return $result;
}

function selectBillCashall()
{
  require 'Connection.php';

  $sql = " SELECT * FROM bill ";

  $result = mysqli_query($conn, $sql);
  return $result;
}



function SelectLoginHistoryFromDatabase()
{
  require 'Connection.php';

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // SQL query to fetch data from the "login_histort_db" table
  $sql = "SELECT * From login_history_db LIMIT 10";
  $result = $conn->query($sql);

  // Close connection
  $conn->close();

  // Return data as an array
  $data = [];
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $data[] = $row;
    }
  }
  return $data;
}

function SelectLoginHistoryall()
{
  require 'Connection.php';

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // SQL query to fetch data from the "login_histort_db" table
  $sql = "SELECT * From login_history_db ";
  $result = $conn->query($sql);

  // Close connection
  $conn->close();

  // Return data as an array

  return $result;
}

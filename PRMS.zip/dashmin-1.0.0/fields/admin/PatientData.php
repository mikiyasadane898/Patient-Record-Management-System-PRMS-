<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <title>DASHMIN - Bootstrap Admin Template</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta content="" name="keywords" />
  <meta content="" name="description" />

  <!-- Favicon -->
  <link href="img/favicon.ico" rel="icon" />

  <!-- Google Web Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet" />

  <!-- Icon Font Stylesheet -->
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet" />

  <!-- Libraries Stylesheet -->
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet" />
  <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

  <!-- Customized Bootstrap Stylesheet -->
  <link href="css/bootstrap.min.css" rel="stylesheet" />

  <!-- Template Stylesheet -->
  <link href="css/style.css" rel="stylesheet" />

  <style>
    .container {
      display: flex;
      flex-direction: row;

    }
  </style>
</head>

<body>
  <div class="container-xxl position-relative bg-white d-flex p-0">
    <!-- Spinner Start -->
    <?php
    include 'headernosearch.php';
    ?>
    <!-- Navbar End -->


    <div class="container-fluid pt-4 px-4">
      <div class="bg-light text-center rounded p-4">
        <div class="d-flex align-items-center justify-content-between mb-4">
          <h6 class="mb-0"></h6>
          <a href=""></a>
        </div>

        <div class="table-responsive">
        <h6> Total Number Of Patients Surved in Year <?php echo  $m = $_POST['datey'];?> Month <?php echo  $m = $_POST['datem'];?> </h6>
          <div class="container">
            
            <table class="table text-start align-middle table-bordered table-hover mb-0">
              <thead>
                <tr class="text-dark">
                  <th scope="col">Data Element</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>male < 5 year </td>
                </tr>
                <tr>
                  <td>Female < 5 year</td>
                </tr>
                <tr>
                  <td>Male 5-10 year</td>
                </tr>
                <tr>
                  <td>Female 5-10 year</td>
                </tr>
                <tr>
                  <td>Male 11-19 year</td>
                </tr>
                <tr>
                  <td>Female 11-19 year</td>
                </tr>
                <tr>
                  <td>Male 20-29 year</td>
                </tr>
                <tr>
                  <td>Female 20-29 year</td>
                </tr>
                <tr>
                  <td>Male 30-45 year</td>
                </tr>
                <tr>
                  <td>Female 30-45 year</td>
                </tr>
                <tr>
                  <td>Male 46-65 year</td>
                </tr>
                <tr>
                  <td>Female 46-65 year</td>
                </tr>
                <tr>
                  <td>Male 65+ year</td>
                </tr>
                <tr>
                  <td>Female 65+ year</td>
                </tr>
              </tbody>
            </table>
            <?php
            ?>
            <table class="table text-start align-middle table-bordered table-hover mb-0">

              <thead>
                <tr class="text-dark">
                  <th scope="col">Count</th>
                </tr>
              </thead>
              <tbody>
              <tbody>
                <?php
                require 'Connection.php';
                require 'Admin.php';

                $sql = selectDetailPatientReport();
              
               
                if (mysqli_multi_query($conn, $sql)) {
                  do {
                    // Store first result set
                    if ($result = mysqli_store_result($conn)) {
                      while ($row = $result->fetch_row()) {
                ?>
                        <tr>
                          <td><?php
                              printf("%s\n", $row[0]); ?></td>
                        </tr>

                <?php
                      }
                      $result->free_result();
                    }
                    // if there are more result-sets, the print a divider
                    //if (mysqli_more_results($conn)) {
                    // 
                    // }
                    //Prepare next result set
                  } while (mysqli_next_result($conn));
                }

                mysqli_close($conn);
                ?>
              </tbody>
            </table>
            <?php
            ?>
          </div>

        </div>
      </div>
    </div>

    <!-- Recent Sales End -->

    <!-- Footer Start -->
    <div class="container-fluid pt-4 px-4">
      <div class="bg-light rounded-top p-4">
        <div class="row">
          <div class="col-12 col-sm-6 text-center text-sm-start">
            &copy; <a href="#">Your Site Name</a>, All Right Reserved.
          </div>
          <div class="col-12 col-sm-6 text-center text-sm-end"></div>
        </div>
      </div>
    </div>
    <!-- Footer End -->
  </div>
  <!-- Content End -->

  <!-- Back to Top -->
  <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
  </div>

  <!-- JavaScript Libraries -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="lib/chart/chart.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/tempusdominus/js/moment.min.js"></script>
  <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
  <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
  <script src="js/sweetalert.min.js"></script>
  <!-- Template Javascript -->
  <script src="js/main.js"></script>
</body>

</html>
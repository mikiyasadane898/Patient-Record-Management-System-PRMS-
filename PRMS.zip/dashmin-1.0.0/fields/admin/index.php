<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Eka Kotebe managment system</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <?php
    require 'script.php';

    ?>
    <style>
        footer {

            left: 0;
            bottom: 0;
            width: 100%;
            margin-top: 14.23%;
            margin-bottom: 0%;
            color: #333;
            padding: 0;
            text-align: center;
        }
    </style>


</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Sidebar Start -->
        <?php
        include 'header and sidebar.php';
        ?>
        <!-- Navbar End -->
        <!-- Sale & Revenue Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="row g-4">
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">

                        <i class="fa fa-solid fa-bed fa-3x text-primary"></i>
                        <div class="ms-3">
                            <p class="mb-2">Patient Number</p>
                            <?php
                            require 'Connection.php';
                            require 'dashboard.php';

                            $data = countPatient();
                            foreach ($data as $row) {
                                echo '<h6 class="mb-0">' . $row['COUNT(Patient_id)'] . '</h6>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                        <i class="fa fa-solid fa-users fa-3x text-primary"></i>

                        <div class="ms-3">
                            <p class="mb-2">Total User</p>
                            <?php
                            require 'Connection.php';


                            $data = countUser();
                            foreach ($data as $row) {
                                echo '<h6 class="mb-0">' . $row['COUNT(User_id)'] . '</h6>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                        <i class="fa fa-chart-area fa-3x text-primary"></i>

                        <div class="ms-3">
                            <p class="mb-2">Total Insurance</p>
                            <?php
                            require 'Connection.php';


                            $data = countinsurance();
                            foreach ($data as $row) {
                                echo '<h6 class="mb-0">' . $row['COUNT(Patient_id)'] . '</h6>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                        <i class="fa fa-solid fa-wallet fa-3x text-primary"></i>
                        <div class="ms-3">
                            <p class="mb-2">Total Sale</p>
                            <?php
                            require 'Connection.php';


                            $data = countsale();
                            foreach ($data as $row) {
                                echo '<h6 class="mb-0">' . $row['COUNT(Patient_id)'] . '</h6>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                        <i class="fa fa-solid fa-vials fa-3x text-primary"></i>


                        <div class="ms-3">
                            <p class="mb-2">Total Test</p>
                            <?php
                            require 'Connection.php';


                            $data = counttest();
                            foreach ($data as $row) {
                                echo '<h6 class="mb-0">' . $row['COUNT(Test_Type)'] . '</h6>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-xl-3">
                    <div class="bg-light rounded d-flex align-items-center justify-content-between p-4">
                        <i class=" fa fa-solid fa-capsules fa-3x text-primary"></i>
                        <div class="ms-3">
                            <p class="mb-2">Total Medicine</p>
                            <?php
                            require 'Connection.php';


                            $data = countmedicine();
                            foreach ($data as $row) {
                                echo '<h6 class="mb-0">' . $row['COUNT(Medicine_Name)'] . '</h6>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Sale & Revenue End -->





        <!-- Footer Start -->
        <footer>
            <span class="container-fluid pt-4 px-4">
                <div class="bg-light rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; Copyright 2024 <label style="color: #009CFF;"> MDBSB</label>. All Right Reserved.
                        </div>

                    </div>
                </div>
            </span>
        </footer>
        <!-- Footer End -->
    </div>
    <!-- Content End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="js/sweetalert.min.js"></script>
    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
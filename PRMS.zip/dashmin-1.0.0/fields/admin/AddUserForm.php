<?php
session_start();
$db_server = "localhost";
$db_user   = "root";
$db_pass   = "";
$db_name   = "ekaprms_db";
$conn =  mysqli_connect($db_server, $db_user, $db_pass, $db_name);
if (!$conn) {
    die("Connection failed! :" . mysqli_connect_error());
}

$query = "SELECT COUNT(User_id) From user_db order by User_id asc";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_array($result);
$lid = $row['COUNT(User_id)'];
$lid = $lid++;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Eka Kotebe managment system</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <script src="js/sweetalert.min.js"></script>
    <script>
        function submitForm(form) {
            swal({
                    title: "Are You Sure",
                    Text: "this form will be submitted",
                    icon: "warning",
                    buttons: [true, "Yes"],
                    dangerMode: true,
                })
                .then((isOkay) => {
                    if (isOkay) {
                        form.submit();
                    }
                });
            return false;
        }
    </script>


    <?php
    require 'script.php';
    ?>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sign Up Start -->
        <form action="AddNewUserphp.php" method="POST" autocomplete="off" enctype="multipart/form-data" onsubmit="return submitForm(this);">

            <div class="container-fluid">
                <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
                    <div class="col-6 col-sm-8 col-md-6 col-lg-12 col-xl-10">
                        <div class="bg-light rounded p-4 p-sm-5 my-4 mx-3">
                            <div class="d-flex align-items-center justify-content-between mb-10">
                                <a href="index.html" class="">
                                    <h6 class="text-primary"></i>ADD USER</h6>
                                </a>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <select name="Role" class="form-control" id="floatingText" onchange="getddl(this)">
                                            <option>Select Role</option>
                                            <option value="Administrator">Administrator</option>
                                            <option value="Doctor">Doctor</option>
                                            <option value="Reception">Reception</option>
                                            <option value="Pharmacist">Pharmacist</option>
                                            <option value="Laboratorian">Laboratorian</option>
                                            <option value="Radiology">Radiology</option>
                                            <option value="Sonographer">Sonographer</option>
                                            <option value="Cashier">Cashier</option>
                                        </select>
                                        <label for="floatingText">Rol</label>
                                    </div>
                                </div>
                                <!--  <div class="col-md-6">
                                <div class="form-floating mb-3">
                                    
                                    <input type="text" class="form-control" id="floatingText" placeholder="jhondoe" value="<?php echo $lid ?>" name="id" readonly>
                                    
                                </div>
                            </div>-->
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" id="floatingText" placeholder="jhondoe" name="Fname" required>
                                        <label for="floatingText">Fname</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" id="floatingText" placeholder="jhondoe" name="Mname" required>
                                        <label for="floatingText">Mname</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" id="floatingText" placeholder="jhondoe" name="Lname" required>
                                        <label for="floatingText">Lname</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="number" class="form-control" id="floatingText" placeholder="jhondoe" name="Age" required>
                                        <label for="floatingText">Age</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <select name="Sex" class="form-control" id="floatingText">
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </select>
                                        <label for="floatingText">Sex</label>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" id="floatingText" placeholder="jhondoe" name="Speciality">
                                        <label for="floatingText">Speciality</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="number" class="form-control" id="floatingText" placeholder="jhondoe" name="Pnumber" required>
                                        <label for="floatingText">Pnumber</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" id="floatingText" placeholder="jhondoe" name="Address" required>
                                        <label for="floatingText">Address</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control" id="floatingText" placeholder="jhondoe" name="User_name" required>
                                        <label for="floatingText">User Name</label>
                                    </div>
                                </div>
                                <div class=" col-md-6">
                                    <div class="form-floating mb-3">
                                        <input class="form-control" type="file" name="image" id="formFile" accept=".jpg, .jpeg, .png" required />
                                        <label for="floatingInput">Profile picture</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating mb-3">
                                        <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
                                        <label for="floatingPassword">Password</label>
                                    </div>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary py-3 w-50 mb-4" name="update_user">ADD</button>
                                <a type="submit" name="cancel" class="btn btn-primary py-3 w-50 mb-4 " href="ViewUser.php">Cancel</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="lib/chart/chart.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/tempusdominus/js/moment.min.js"></script>
        <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
        <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
        <script src="js/sweetalert.min.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
        
    <?php
    if(isset($_SESSION['status']) && $_SESSION['status'] != ''){
    ?>
    <script>
        swal({
            title: '<?php echo $_SESSION['status'];?>',
            text: '<?php echo $_SESSION['status_code'];?>',
            icon: "error",
            button: "Okay!",
        });
    </script>
    <?php
    unset($_SESSION['status']);
}
?>
</body>

</html>
<?php
session_start();


require 'Connection.php';

date_default_timezone_set('Africa/Nairobi');

$Role = $_POST["Role"];
$user_id = $_POST["User_id"];
$Fname = $_POST["FirstName"];
$Mname = $_POST["MiddleName"];
$Lname = $_POST["LastName"];
$Age = $_POST["Age"];
$Sex = $_POST["Sex"];
$Speciality = $_POST["Specialty"];
$Pnumber = $_POST["PhoneNumber"];
$Address = $_POST["Address"];
$User_name = $_POST["Username"];
$pass = $_POST["Password"];
$hashedpassword = password_hash($pass, PASSWORD_BCRYPT);
$Password = $hashedpassword;
$Date = date('m-d-y h:i:sa');

$sqlu = "SELECT Username FROM user_db WHERE Username = '$User_name'";
$uresult = mysqli_query($conn, $sqlu);

$query = "SELECT Password FROM user_db";
$resultp = $conn->query($query);
$hashed_passwords = array();
while ($row = $resultp->fetch_assoc()) {
  $hashed_passwords[] = $row['Password'];
}

if($hashed_passwords){
  foreach ($hashed_passwords as $hashed_password) {
    $h = $hashed_password;
    if (password_verify($pass, $h)) {
      $_SESSION['h'] = "match";
    }
  }}




if ($uresult->num_rows > 0) {
  $_SESSION['status'] = " Duplicated UserName please Try Again";
  $_SESSION['status_code'] = "Error";
  header("Location: EdituserForm.php?User_id=$user_id?update=error");
} elseif(isset($_SESSION['h'])){
        $_SESSION['status'] = " Duplicated Password please Try Again";
      $_SESSION['status_code'] = "Error";
      header("Location: EdituserForm.php?User_id=$user_id?update=error");
      unset($_SESSION['h']);
} else {

  $sql = " UPDATE user_db SET FirstName='$Fname', MiddleName='$Mname', LastName='$Lname', Age='$Age', Sex='$Sex', Specialty='$Speciality', 
  Role='$Role', PhoneNumber='$Pnumber', Address='$Address', Username='$User_name', Password='$Password', LastUpdatedDate='$Date'
  WHERE User_id = '$user_id' ";

  $result = mysqli_query($conn, $sql);

  if ($result) {
    $_SESSION['status'] = " Updated Successfully";
    $_SESSION['status_code'] = "success";
    header("Location: ../../fields/admin/ViewUser.php?update=success");
  } else {
    $_SESSION['status'] = "Not Updated Successfully";
    $_SESSION['status_code'] = "error";
    header("Location: EdituserForm.php?update=error");
  }
}

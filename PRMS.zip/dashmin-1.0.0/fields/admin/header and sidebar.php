<?php
session_start();


if (!isset($_SESSION['A']) || !isset($_SESSION['FirstName'])){

  header('Location:../../index.php');
  session_destroy();
}

?>
<?php
// Database connection
require 'Connection.php';

$ui = $_SESSION['user_id'];
// Retrieve image data from the database
$sql = "SELECT ProfilePicture FROM user_db WHERE User_id = '$ui'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
  $image_data = $row["ProfilePicture"];

  // Display the image
  $n =  $row["ProfilePicture"];
  $_SESSION['p'] = $n;
  
} else {
  echo "Image not found";
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="../admin/css/style.css">
  <script src="sweetalert.min.js"></script>
  <script>
    function submitForm(form) {
      swal({
          title: "Are You Sure ?",
          Text: "this form will be submitted",
          icon: "warning",
          buttons: [true, "Yes"],
          dangerMode: true,
        })
        .then((isOkay) => {
          if (isOkay) {
            form.submit();
          }
        });
      return false;
    }


    
  </script>
 

</head>

<body>
  <span class="container-xxl position-relative bg-white d-flex p-0">
   
    <!-- Sidebar Start -->
    <div class="sidebar pe-4 pb-3">
      <nav class="navbar bg-light navbar-light">
        <a href="index.html" class="navbar-brand mx-4 mb-3">
          <h5 class="text-primary">Eka Kotebe(PMS)</h5>
        </a>
        <div class="d-flex align-items-center ms-4 mb-4">
          <div class="position-relative">
            <?php

            echo '<img class="rounded-circle"  src="../../i/' . $_SESSION['p'] . '" style="width: 40px; height: 40px">';
            ?>

            <div class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1"></div>
          </div>
          <div class="ms-3">
            <h6 class="mb-0"><?php print($_SESSION['FirstName'] . ' ' . $_SESSION['MiddleName']);
                              ?></h6>
            <span>Admin</span>
          </div>
        </div>
        <div class="navbar-nav w-100">
          <a href="index.php" class="nav-item nav-link active" ><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>

          <div class="nav-item dropdown">
            <a href="#" class="nav-link dropdown-toggle " data-bs-toggle="dropdown"><i class="fa fa-laptop me-2"></i>Report</a>
            <div class="dropdown-menu bg-transparent border-0">

              <a href="PatienReport.php" class="dropdown-item">Patient Report</a>
              <a href="login-History.php" class="dropdown-item">Login History</a>
              <a href="billreport.php" class="dropdown-item">Bill Report</a>
            </div>
          </div>
          <a href="ViewUser.php" class="nav-item nav-link "><i class="fa fa-table me-2"></i>User</a>

        </div>
      </nav>
    </div>
    <!-- Sidebar End -->

    <!-- Content Start -->
    <div class="content">
      <!-- Navbar Start -->
      <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 ">
        
        <a href="#" class="sidebar-toggler flex-shrink-0">
          <i class="fa fa-bars"></i>
        </a>
        <form class="d-none d-md-flex ms-4">
          <input class="form-control border-0" type="text" placeholder="Search" onkeyup="showUser(this.value)" />
        </form>
        <div class="navbar-nav align-items-center ms-auto">
          <div class="">
            <form action="../../logout.php" method="post" onsubmit="return submitForm(this);">
              <a class="nav-link ">
                <button class="btn btn-outline-primary m-2" type="submit">Log Out </button>
              </a>
            </form>
          </div>
        </div>
      </nav>
      <!-- Navbar End -->
  </span>     

</body>

</html>
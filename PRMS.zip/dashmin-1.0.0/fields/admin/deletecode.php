<?php
require 'Connection.php';

if(isset($_POST['deletedata']))
{session_start();
    $id = $_POST['delete_id'];

    $query = "DELETE FROM user_db WHERE User_id = '$id'";
    $query_run = mysqli_query($conn, $query);
    if ($query_run) {
        $_SESSION['status'] = " User Deleted Successfully";
        $_SESSION['status_code'] = "success";
        header("Location: ../../fields/admin/ViewUser.php?update=success");
      } else {
        $_SESSION['status'] = " User Not Deletes  Successfully";
        $_SESSION['status_code'] = "error";
        header("Location: ViewUser.php?update=error");
      }
   
}

?>
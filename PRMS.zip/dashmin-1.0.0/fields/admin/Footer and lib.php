<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        footer {
    
    left: 0;
    bottom: 0;
    width: 100%;
    margin-top: 0%;
    color: #333;
    padding: 0;
    text-align: center;
}


    </style>
</head>

<body>

    <!-- Footer Start -->
    <footer>
        <span class="container-fluid pt-4 px-4">
            <div class="bg-light rounded-top p-4">
                <div class="row">
                    <div class="col-12 col-sm-6 text-center text-sm-start" >
                    &copy; Copyright 2024 <label style="color: #009CFF;"> MDBSB</label>. All Right Reserved.
                    </div>
                    
                </div>
            </div>
        </span>
         </footer>
    <!-- Footer End -->
    </div>
    <!-- Content End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="js/sweetalert.min.js"></script>
    
    <?php
    if(isset($_SESSION['status']) && $_SESSION['status'] != ''){
    ?>
    <script>
        swal({
            title: '<?php echo $_SESSION['status'];?>',
            text: '<?php echo $_SESSION['status_code'];?>',
            icon: "success",
            button: "Okay!",
        });
    </script>
    <?php
    unset($_SESSION['status']);
}
?>
    <!-- Template Javascript -->
    <script src="js/main.js"></script>

</body>

</html>
<?php
session_start();


if (!isset($_SESSION['A']) || !isset($_SESSION['FirstName'])){

  header('Location:../../index.php');
  session_destroy();
}

?>


<?php

require 'Connection.php';

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch data from the "myTable" table
$sql = "SELECT * From user_db";
$result = $conn->query($sql);

// Close connection
$conn->close();

// Return data as an array
$data = [];
if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $data[] = $row;
  }
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <title>Eka Kotebe managment system</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta content="" name="keywords" />
  <meta content="" name="description" />
  <script src="sweetalert.min.js"></script>
  <?php
  require 'script.php';

  ?>
  <script>
    function showUser(str) {

      var xmlhttp = new XMLHttpRequest();
      xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          document.getElementById("table-view").innerHTML = this.responseText;
        }
      };
      xmlhttp.open("GET", "Search.php/search()?q=" + str, true);
      xmlhttp.send();
    }
  </script>

  <script>
    function submitForm(form) {
      swal({
          title: "Are You Sure ?",
          Text: "this form will be submitted",
          icon: "warning",
          buttons: [true, "Yes"],
          dangerMode: true,
        })
        .then((isOkay) => {
          if (isOkay) {
            form.submit();
          }
        });
      return false;
    }


    
  </script>

</head>

<body>
  <div class="container-xxl position-relative bg-white d-flex p-0">
  <span class="container-xxl position-relative bg-white d-flex p-0">
   
   <!-- Sidebar Start -->
   <div class="sidebar pe-4 pb-3">
     <nav class="navbar bg-light navbar-light">
       <a href="index.html" class="navbar-brand mx-4 mb-3">
         <h5 class="text-primary">Eka Kotebe(PMS)</h5>
       </a>
       <div class="d-flex align-items-center ms-4 mb-4">
         <div class="position-relative">
           <?php

           echo '<img class="rounded-circle"  src="../../i/' . $_SESSION['p'] . '" style="width: 40px; height: 40px">';
           ?>

           <div class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1"></div>
         </div>
         <div class="ms-3">
           <h6 class="mb-0"><?php print($_SESSION['FirstName'] . ' ' . $_SESSION['MiddleName']);
                             ?></h6>
           <span>Admin</span>
         </div>
       </div>
       <div class="navbar-nav w-100">
         <a href="index.php" class="nav-item nav-link " ><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>

         <div class="nav-item dropdown">
           <a href="../../fields/admin/PatienReport.php" class="nav-link dropdown-toggle " data-bs-toggle="dropdown"><i class="fa fa-laptop me-2"></i>Report</a>
           <div class="dropdown-menu bg-transparent border-0">

             <a href="PatienReport.php" class="dropdown-item">Patient Report</a>
             <a href="login-History.php" class="dropdown-item">Login History</a>
             <a href="billreport.php" class="dropdown-item">Bill Report</a>
           </div>
         </div>
         <a href="ViewUser.php" class="nav-item nav-link active "><i class="fa fa-table me-2"></i>User</a>

       </div>
     </nav>
   </div>
   <!-- Sidebar End -->

   <!-- Content Start -->
   <div class="content">
     <!-- Navbar Start -->
     <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 ">
       
       <a href="#" class="sidebar-toggler flex-shrink-0">
         <i class="fa fa-bars"></i>
       </a>
       <form class="d-none d-md-flex ms-4">
         <input class="form-control border-0" type="text" placeholder="Search" onkeyup="showUser(this.value)" />
       </form>
       <div class="navbar-nav align-items-center ms-auto">
         <div class="">
           <form action="../../logout.php" method="post" onsubmit="return submitForm(this);">
             <a class="nav-link ">
               <button class="btn btn-outline-primary m-2" type="submit">Log Out </button>
             </a>
           </form>
         </div>
       </div>
     </nav>
     <!-- Navbar End -->
 </span>     


    <!-- edit user Start -->
    <div class="container-fluid pt-4 px-4">
      <div class="bg-light text-center rounded p-4" id="table-view">
        <div class="d-flex align-items-center justify-content-between mb-4">

          <h6 class="mb-0">All Users</h6>
          <a class="btn btn-sm btn-primary" href="AddUserForm.php">ADD USER</a>
        </div>

        <div class="table-responsive">
          <table class="table text-start align-middle table-bordered table-hover mb-0">
            <thead>
              <tr class="text-dark">
                <th scope="col">User ID</th>
                <th scope="col">FirstName</th>
                <th scope="col">MiddleName</th>
                <th scope="col">LastName</th>
                <th scope="col">Sex</th>
                <th scope="col">Age</th>
                <th scope="col">Rol</th>
                <th scope="col">Username</th>
                <th scope="col">Specialty</th>
                <th scope="col">Phone Number</th>
                <th scope="col">Address</th>
                <th scope="col">Profile</th>
                <th scope="col">Date</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>


              </tr>
            </thead>
            <tbody>
              <?php
              require 'Connection.php';
              require 'Admin.php';
              $data = SelectUserFromDatabase();

              foreach ($data as $row) {
                $_SESSION['p'] = $row["ProfilePicture"];
                echo '<tr>';
                echo '<td>' . $row["User_id"] . '</td>';
                echo '<td>' . $row["FirstName"] . '</td>';
                echo '<td>' . $row["MiddleName"] . '</td>';
                echo '<td>' . $row["LastName"] . '</td>';
                echo '<td>' . $row["Sex"] . '</td>';
                echo '<td>' . $row["Age"] . '</td>';
                echo '<td>' . $row["Role"] . '</td>';
                echo '<td>' . $row["Username"] . '</td>';
                echo '<td>' . $row["Specialty"] . '</td>';
                echo '<td>' . $row["PhoneNumber"] . '</td>';
                echo '<td>' . $row["Address"] . '</td>';
                echo '<td>' . '<img class="rounded-circle" src="../../i/' . $row['ProfilePicture'] . '" style="width: 40px; height: 40px" />' . '</td>';
                echo '<td>' . $row["Date"] . '</td>';
                echo '<td>' . '<a class="btn btn-outline-primary m-2" href="EdituserForm.php?User_id=' . $row["User_id"] . '">Edit</a>' . '</td>';
              ?>

                <td>
                  <button type="button" class="btn btn-outline-danger mb-2 deletebtn"> DELETE </button>
                </td>
                
               
              <?php
                echo '</tr>';
              }

              echo '</table>';
              ?>

            </tbody>
          </table>
        </div>
      </div>
    </div>
    <!-- edit user End -->
    <div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"> Delete User </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>

          <form action="deletecode.php" method="POST">

            <div class="modal-body">

              <input type="hidden" name="delete_id" id="delete_id">

              <h4> Do you want to Delete User ?</h4>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal"> NO </button>
              <button type="submit" name="deletedata" class="btn btn-primary"> Yes </button>
            </div>
          </form>

        </div>
      </div>
    </div>




    <?php
    include('Footer and lib.php');
    ?>

    <script>
      $(document).ready(function() {

        $('.deletebtn').on('click', function() {

          $('#deletemodal').modal('show');

          $tr = $(this).closest('tr');

          var data = $tr.children("td").map(function() {
            return $(this).text();
          }).get();

          console.log(data);

          $('#delete_id').val(data[0]);

        });
      });
    </script>
  </div>
</body>

</html>
<?php
function countPatient()
{
    include 'Connection.php';
    $sql = "SELECT COUNT(Patient_id) FROM patient_db";
    $result = mysqli_query($conn, $sql);
    return $result;
}

function countUser()
{
    include 'Connection.php';
    $sql = "SELECT COUNT(User_id) FROM User_db";
    $result = mysqli_query($conn, $sql);
    return $result;
}


function countinsurance()
{
    include 'Connection.php';
    $sql = "SELECT DISTINCT COUNT(Patient_id) FROM insurance_db";
    $result = mysqli_query($conn, $sql);
    return $result;
}

function countsale()
{
    include 'Connection.php';
    $sql = "SELECT DISTINCT COUNT(Patient_id) FROM bill";
    $result = mysqli_query($conn, $sql);
    return $result;
}
function counttest()
{
    include 'Connection.php';
    $sql = "SELECT DISTINCT COUNT(Test_Type) FROM test_price_db";
    $result = mysqli_query($conn, $sql);
    return $result;
}

function countmedicine()
{
    include 'Connection.php';
    $sql = "SELECT DISTINCT COUNT(Medicine_Name) FROM medicine_price_db";
    $result = mysqli_query($conn, $sql);
    return $result;
}


?>

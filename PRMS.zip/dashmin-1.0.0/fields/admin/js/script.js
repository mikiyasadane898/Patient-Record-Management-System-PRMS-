const dropdown = document.getElementById('myfield');
const loginButton = document.getElementById('loginButton');

loginButton.addEventListener('click', () => {
  const selectedValue = dropdown.value;
  if (selectedValue) {
    window.location.href = selectedValue;
  } else {
    // Handle no selection case (optional)
    alert("Please select a location first!");
  }
});
<?php

session_start();
  
  require 'Connection.php';
  $insurancecode = $_POST['icode'];
  $userid = $_SESSION['user_id'];
  $patientid = $_SESSION['patient_id '];
  $address = $_POST['address'];
  
  $sql = "UPDATE  insurance_db SET Insurance_code = '$insurancecode', Cashier_id = '$userid', Address = '$address' WHERE Patient_id = '$patientid' AND Insurance_code IS NULL";
  $result = mysqli_query($conn, $sql);
  
 
  if ($result) {
    require "Cashier.php";
     $data = selectInsuranceBill();
     if($data -> num_rows >0){
      $_SESSION['status'] = " Receipt Number Added Successfully";
      $_SESSION['status_code'] = "success";
      header("Location:InsuranceBills.php?addInsuranceCode=success");}
      else{
        $_SESSION['status'] = " All Bill Succeed";
      $_SESSION['status_code'] = "success";
      header("Location:Bills.php?addInsuranceCode=success");
      }
  } else {
    $_SESSION['status'] = " Receipt Number Not Added  Successfully";
    $_SESSION['status_code'] = "error";
    header("Location:ViewInsurance.php?addInsuranceCode=error");
  }
  
  
  ?>
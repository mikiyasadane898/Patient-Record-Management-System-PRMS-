<?php
function selectBill()  {


require 'Connection.php';

  $sql1 = "SELECT DISTINCT p.Patient_id, p.FirstName, p.MiddleName, p.LastName, p.Age, p.Sex, p.Date
  FROM patient_db p INNER JOIN bill_db b ON p.Patient_id = b.Patient_id  ";
  $result = $conn->query($sql1);
 
    return $result;
}
function selectPatientName(){
  require 'Connection.php';
  $patientid = $_POST['patient_id'];
  $sql = " SELECT DISTINCT * FROM patient_db WHERE Patient_id = '$patientid'";
  
  $result = mysqli_query($conn, $sql);
  return $result;
}


function selectInsuranceBill() {
  require 'Connection.php';



$sql = " SELECT DISTINCT(d.Age), p.Patient_id, p.FirstName, p.MiddleName, p.LastName, p.Sex 
  FROM patient_db p INNER JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
  INNER JOIN insurance_db i ON p.Patient_id = i.Patient_id 
  WHERE i.Insurance_code IS NULL ";

  

  $result = mysqli_query($conn, $sql);
  return $result;
  
}


function selectCashBill() {
  require 'Connection.php';
  $sql = " SELECT DISTINCT(d.Age), p.Patient_id, p.FirstName, p.MiddleName, p.LastName, p.Sex FROM patient_db p
   INNER JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
  INNER JOIN bill b ON p.Patient_id = b.Patient_id 
  WHERE b.Receipt_number IS NULL";

  $result = mysqli_query($conn, $sql);
  return $result;
  
}


function selectNameBillCash() {
  require 'Connection.php';
  $patientid = $_POST['patient_id'];
  $sql = " SELECT DISTINCT p.Patient_id, p.FirstName, p.MiddleName, p.LastName, d.Age, p.Sex
  FROM patient_db p INNER JOIN bill b ON p.Patient_id = b.Patient_id
  INNER JOIN diagnosis_db d ON p.Patient_id = d.Patient_id
  WHERE p.Patient_id = '$patientid' AND Receipt_number IS NULL ";

  $result = mysqli_query($conn, $sql);
  return $result;
  
}



function selectBillCashDetail() {
  require 'Connection.php';
  $patientid = $_POST['patient_id'];
  $sql = " SELECT DISTINCT b.*
  FROM patient_db p INNER JOIN bill b ON p.Patient_id = b.Patient_id
  WHERE p.Patient_id = '$patientid' AND b.Receipt_number IS NULL";

  $result = mysqli_query($conn, $sql);
  return $result;
  
}

if(isset($_POST['addreceipt'])){
  addReceipt();
}

function addReceipt() {
session_start();

require 'Connection.php';
$receiptnumber = $_POST['rnumber'];
$userid = $_SESSION['user_id'];
$patientid = $_SESSION['patient_id '];

$sql = "UPDATE bill SET Receipt_number = '$receiptnumber', Cashier_id = '$userid' WHERE Patient_id = '$patientid' AND Receipt_number IS NULL ";
$result = mysqli_query($conn, $sql);

if ($result) {
  $data = selectCashBill();
  if($data -> num_rows >0){
  $_SESSION['status'] = " Receipt Number Added Successfully";
  $_SESSION['status_code'] = "success";
  header("Location:CashBills.php?addreceipt=success");}
  else{
    $_SESSION['status'] = " All Bill Succeed";
  $_SESSION['status_code'] = "success";
  header("Location:Bills.php?addreceipt=success");
  }
} else {
  $_SESSION['status'] = " Receipt Number Not Added  Successfully";
  $_SESSION['status_code'] = "error";
  header("Location:ViewCash.php?addreceipt=error");
}
}


function selectNameBillInsurance() {
  require 'Connection.php';
  $patientid = $_POST['patient_id'];
 
$sql = " SELECT DISTINCT p.Patient_id, p.FirstName, p.MiddleName, p.LastName, d.Age, p.Sex FROM patient_db p
 INNER JOIN insurance_db i ON p.Patient_id = i.Patient_id 
 INNER JOIN diagnosis_db d ON p.Patient_id = d.Patient_id 
 WHERE p.Patient_id = '$patientid' AND i.Insurance_code IS NULL";

  $result = mysqli_query($conn, $sql);
  return $result;
  
  
}



function selectBillInsuranceDetail() {
  require 'Connection.php';
  $patientid = $_POST['patient_id'];
  $sql = " SELECT DISTINCT i.*
  FROM patient_db p INNER JOIN insurance_db i ON p.Patient_id = i.Patient_id
  WHERE p.Patient_id = '$patientid' AND i.insurance_code IS NULL ";

  $result = mysqli_query($conn, $sql);
  return $result;
  
}

if(isset($_POST['addicode'])){
  addInsuranceCode();
}
function addInsuranceCode() {
  session_start();
  
  require 'Connection.php';
  $insurancecode = $_POST['icode'];
  $userid = $_SESSION['user_id'];
  $patientid = $_SESSION['patient_id '];
  $address = $_POST['address'];
  
  $sql = "UPDATE  insurance_db SET Insurance_code = '$insurancecode', Cashier_id = '$userid', Address = '$address' WHERE Patient_id = '$patientid' AND Insurance_code IS NULL";
  $result = mysqli_query($conn, $sql);
  
 
  if ($result) {
     $data = selectInsuranceBill();
     if($data -> num_rows >0){
      $_SESSION['status'] = " Receipt Number Added Successfully";
      $_SESSION['status_code'] = "success";
      header("Location:InsuranceBills.php?addInsuranceCode=success");}
      else{
        $_SESSION['status'] = " All Bill Succeed";
      $_SESSION['status_code'] = "success";
      header("Location:Bills.php?addInsuranceCode=success");
      }
  } else {
    $_SESSION['status'] = " Receipt Number Not Added  Successfully";
    $_SESSION['status_code'] = "error";
    header("Location:ViewInsurance.php?addInsuranceCode=error");
  }
  
  
    
  }


?>
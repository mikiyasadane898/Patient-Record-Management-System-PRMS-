<?php

    session_start();
    
    require 'Connection.php';
    $receiptnumber = $_POST['rnumber'];
    $userid = $_SESSION['user_id'];
    $patientid = $_SESSION['patient_id '];
    
    $sql = "UPDATE bill SET Receipt_number = '$receiptnumber', Cashier_id = '$userid' WHERE Patient_id = '$patientid' AND Receipt_number IS NULL ";
    $result = mysqli_query($conn, $sql);
    
    if ($result) {
      require 'Cashier.php';
      $data = selectCashBill();
      if($data -> num_rows >0){
      $_SESSION['status'] = " Receipt Number Added Successfully";
      $_SESSION['status_code'] = "success";
      header("Location:CashBills.php?addreceipt=success");}
      else{
        $_SESSION['status'] = " All Bill Succeed";
      $_SESSION['status_code'] = "success";
      header("Location:Bills.php?addreceipt=success");
      }
    } else {
      $_SESSION['status'] = " Receipt Number Not Added  Successfully";
      $_SESSION['status_code'] = "error";
      header("Location:ViewCash.php?addreceipt=error");
    }
    

?>
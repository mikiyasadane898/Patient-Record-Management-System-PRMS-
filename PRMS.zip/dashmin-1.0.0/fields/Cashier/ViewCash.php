<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DASHMIN - Bootstrap Admin Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <?php
    require 'header.php';
    ?>


    <!-- view patient table Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light  rounded p-4">
            <h6 class="text-primary">Patient Information</h6>
            <div class="d-flex align-items-center justify-content-between mb-4">
                <div class="col-sm-12 col-xl-12">
                    <div class="table-responsive">
                        <?php
                        require 'Connection.php';
                        require 'Cashier.php';

                        $data = selectNameBillCash();
                        while ($row = $data->fetch_assoc()) {
                            echo '<label for="Patient ID" class="col-sm-2">Patient ID</label>';
                            echo '<lable id = "Patient ID" class="col-sm-6">' . $row["Patient_id"] . '</label>' . '<br>';
                            echo '<label for="FirstName" class="col-sm-2">FirstName</label>';
                            echo '<lable id = "FirstName" class="col-sm-6">' . $row["FirstName"] . '</label>' . '<br>';
                            echo '<label for="MiddleName" class="col-sm-2">MiddleName</label>';
                            echo '<lable id = "MiddleName" class="col-sm-6">' . $row["MiddleName"] . '</label>' . '<br>';
                            echo '<label for="LastName" class="col-sm-2">LastName</label>';
                            echo '<lable id = "LastName" class="col-sm-6">' . $row["LastName"] . '</label>' . '<br>';
                            echo '<label for="Age" class="col-sm-2">Age</label>';
                            echo '<lable id = "Age" class="col-sm-6">' . $row["Age"] . '</label>' . '<br>';
                            echo '<label for="Sex" class="col-sm-2">Sex</label>';
                            echo '<lable id = "Sex" class="col-sm-6">' . $row["Sex"] . '</label>' . '<br>';

                            $_SESSION['patient_id '] = $row["Patient_id"];
                        }

                        ?>
                    </div>
                </div>
            </div>

            <h6 class="text-primary">Receipt Number</h6>
            <div class="row">
            <form action='AddReceipt.php' method='POST' onsubmit="return submitForm(this);" >
                <div class="col-md-6">
                    <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="floatingText" placeholder="jhondoe" name="rnumber" required >
                        <label for="floatingText">Enter Receipt Number</label>
                    </div>
                    <button type='submit' class='btn btn-outline-primary mb-2' name="addreceipt">Save</button>
                </div>
            </form>
            </div>
            <br>

            


            <!-- view patient table End -->


            <!-- Bill List Start -->

            <h6 class="text-primary">List Of Bills</h6>
            <div class="bg-light text-center rounded p-4">
                <div class="table-responsive">
                    <?php
                    require 'Connection.php';

                    $data = selectBillCashDetail();
                    if ($data->num_rows > 0) {
                    ?>
                        <table class="table text-start align-middle table-bordered table-hover mb-0">
                            <thead>
                                <tr class="text-dark">
                                    <th scope="col">Order_Number</th>
                                    <th scope="row">Quantity</th>
                                    <th scope="row">Reason</th>
                                    <th scope="col">Description</th>
                                    <th scope="row">Unit_Price</th>
                                    <th scope="row">Total_Price</th>
                                    <th scope="row">Date</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php

                            foreach ($data as $row) {
                                echo '<tr>';
                                echo '<td>' . $row["Order_Number"] . '</td>';
                                echo '<td>' . $row["Quantity"] . '</td>';
                                echo '<td>' . $row["Reason"] . '</td>';
                                echo '<td>' . $row["Description"] . '</td>';
                                echo '<td>' . $row["Unit_Price"] . '</td>';
                                echo '<td>' . $row["Total_Price"] . '</td>';
                                echo '<td>' . $row["Date"] . '</td>';
                                $_SESSION['patient_id'] = $row["Patient_id"];
                                echo '</tr>';
                            }
                        } else {
                            echo " No Record";
                        }
                            ?>

                            </tbody>
                        </table>
                </div>
            </div>
        </div>
    </div>




    <!-- Bill List End -->


<!-- Footer Start -->
<footer>
        <span class="container-fluid pt-4 px-4">
            <div class="bg-light rounded-top p-4">
                <div class="row">
                    <div class="col-12 col-sm-6 text-center text-sm-start" >
                    &copy; Copyright 2024 <label style="color: #009CFF;"> MDBSB</label>. All Right Reserved.
                    </div>
                    
                </div>
            </div>
        </span>
         </footer>
            <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="js/sweetalert.min.js"></script>
    
    <?php
    if(isset($_SESSION['status']) && $_SESSION['status'] != ''){
    ?>
    <script>
        swal({
            title: '<?php echo $_SESSION['status'];?>',
            text: '<?php echo $_SESSION['status_code'];?>',
            icon: "error",
            button: "Okay!",
        });
    </script>
    <?php
    unset($_SESSION['status']);
}
?>
    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 07, 2024 at 08:55 AM
-- Server version: 8.2.0
-- PHP Version: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ekaprms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
CREATE TABLE IF NOT EXISTS `bill` (
  `Order_Number` int NOT NULL AUTO_INCREMENT,
  `Patient_id` int NOT NULL,
  `Receipt_Number` int DEFAULT NULL,
  `Quantity` int NOT NULL,
  `Reason` varchar(255) NOT NULL,
  `Description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Unit_Price` float NOT NULL,
  `Total_Price` float NOT NULL,
  `Payment_method` varchar(30) NOT NULL,
  `Cashier_id` varchar(10) NOT NULL,
  `Date` varchar(30) NOT NULL,
  PRIMARY KEY (`Order_Number`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `diagnosis_db`
--

DROP TABLE IF EXISTS `diagnosis_db`;
CREATE TABLE IF NOT EXISTS `diagnosis_db` (
  `Patient_id` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Age` int DEFAULT NULL,
  `Finding` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Symptoms` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `Test_id` int DEFAULT NULL,
  `Doctor_Suggestion` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `Prescription_id` int DEFAULT NULL,
  `Doctor_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Date` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `insurance_db`
--

DROP TABLE IF EXISTS `insurance_db`;
CREATE TABLE IF NOT EXISTS `insurance_db` (
  `Order_Number` int NOT NULL AUTO_INCREMENT,
  `Patient_id` varchar(10) NOT NULL,
  `Insurance_code` int DEFAULT NULL,
  `Quantity` int NOT NULL,
  `Reason` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Unit_Price` float NOT NULL,
  `Total_Price` float NOT NULL,
  `Payment_method` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Cashier_id` varchar(20) NOT NULL,
  `Date` varchar(20) NOT NULL,
  PRIMARY KEY (`Order_Number`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_history_db`
--

DROP TABLE IF EXISTS `login_history_db`;
CREATE TABLE IF NOT EXISTS `login_history_db` (
  `User_id` varchar(10) NOT NULL,
  `User_name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Login_Time` time(6) NOT NULL,
  `Logout_Time` time(6) DEFAULT NULL,
  `Day` varchar(20) NOT NULL,
  `Date` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `login_history_db`
--

INSERT INTO `login_history_db` (`User_id`, `User_name`, `Login_Time`, `Logout_Time`, `Day`, `Date`) VALUES
('1', 'mikiadane8', '11:42:55.000000', NULL, 'Monday', '10-07-24'),
('21', 'samitt', '11:47:27.000000', NULL, 'Friday', '07-05-24'),
('19', 'samit', '11:44:29.000000', '11:47:05.000000', 'Friday', '07-05-24'),
('8', 'rece', '11:43:15.000000', '11:43:31.000000', 'Friday', '07-05-24'),
('1', 'mikiadane8', '11:41:57.000000', '11:43:01.000000', 'Friday', '07-05-24'),
('18', 'ethio@1140', '08:39:36.000000', NULL, 'Friday', '07-05-24'),
('8', 'rece', '08:35:08.000000', '11:43:31.000000', 'Friday', '07-05-24'),
('18', 'ethio@1140', '08:34:04.000000', '08:34:14.000000', 'Friday', '07-05-24'),
('12', 'sono', '08:33:18.000000', '08:33:41.000000', 'Friday', '07-05-24'),
('18', 'ethio@1140', '08:29:37.000000', '08:34:14.000000', 'Friday', '07-05-24'),
('1', 'mikiadane8', '12:28:04.000000', '11:43:01.000000', 'Friday', '07-05-24'),
('4', 'lab', '12:27:38.000000', '12:28:10.000000', 'Friday', '07-05-24'),
('1', 'mikiadane8', '12:26:44.000000', '11:43:01.000000', 'Friday', '07-05-24'),
('1', 'mikiadane8', '12:13:17.000000', '11:43:01.000000', 'Friday', '07-05-24'),
('1', 'mikiadane8', '11:54:20.000000', '11:43:01.000000', 'Thursday', '07-04-24'),
('1', 'mikiadane8', '12:26:03.000000', '11:43:01.000000', 'Friday', '07-05-24');

-- --------------------------------------------------------

--
-- Table structure for table `medicine_price_db`
--

DROP TABLE IF EXISTS `medicine_price_db`;
CREATE TABLE IF NOT EXISTS `medicine_price_db` (
  `Medicine_Name` varchar(30) NOT NULL,
  `Dos` varchar(15) NOT NULL,
  `Quantity` int NOT NULL,
  `Price` float NOT NULL,
  `Sold_Amount` int NOT NULL,
  `Remain_Amount` int NOT NULL,
  `Added_By` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Date` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `LastUpdatedDate` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`Medicine_Name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `medicine_price_db`
--

INSERT INTO `medicine_price_db` (`Medicine_Name`, `Dos`, `Quantity`, `Price`, `Sold_Amount`, `Remain_Amount`, `Added_By`, `Date`, `LastUpdatedDate`) VALUES
('Parastamol', '500mg', 100, 10, 6, 94, 'Mekdes Adane', '07-03-24 12:16:34pm', '07-03-24 12:16:48pm'),
('hyprophine', '50mg', 100, 200, 0, 100, 'Mekdes Adane', '07-03-24 12:22:03pm', '07-03-24 01:17:45pm'),
('insulin', '100mg', 100, 1000, 0, 100, 'Mekdes Adane', '07-03-24 12:46:47pm', '07-03-24 01:18:07pm');

-- --------------------------------------------------------

--
-- Table structure for table `patient_db`
--

DROP TABLE IF EXISTS `patient_db`;
CREATE TABLE IF NOT EXISTS `patient_db` (
  `Patient_id` int NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `MiddleName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `LastName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Sex` varchar(5) NOT NULL,
  `Age` int NOT NULL,
  `PhoneNumber` int NOT NULL,
  `Address` varchar(30) NOT NULL,
  `Date` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`Patient_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `prescription_db`
--

DROP TABLE IF EXISTS `prescription_db`;
CREATE TABLE IF NOT EXISTS `prescription_db` (
  `Prescription_id` int NOT NULL AUTO_INCREMENT,
  `Patient_id` varchar(10) NOT NULL,
  `Medicine_name` varchar(30) NOT NULL,
  `Dose` varchar(20) NOT NULL,
  `Days` int NOT NULL,
  `Per_Day` int NOT NULL,
  `Doctor_id` varchar(10) NOT NULL,
  `Pharmacist_id` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Date` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`Prescription_id`)
) ENGINE=MyISAM AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `test_db`
--

DROP TABLE IF EXISTS `test_db`;
CREATE TABLE IF NOT EXISTS `test_db` (
  `Patient_id` varchar(10) NOT NULL,
  `Test_id` int NOT NULL AUTO_INCREMENT,
  `Clinical_Diagnosis` varchar(255) NOT NULL,
  `Test_Type` varchar(255) NOT NULL,
  `Requested_Test` mediumtext NOT NULL,
  `Test_Result` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `Doctor_id` varchar(30) NOT NULL,
  `Professional_id` varchar(30) NOT NULL,
  `Date` varchar(30) NOT NULL,
  PRIMARY KEY (`Test_id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `test_price_db`
--

DROP TABLE IF EXISTS `test_price_db`;
CREATE TABLE IF NOT EXISTS `test_price_db` (
  `Test_Type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Price` float NOT NULL,
  `Added_By` varchar(30) NOT NULL,
  `Date` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `LastUpdatedDate` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`Test_Type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `test_price_db`
--

INSERT INTO `test_price_db` (`Test_Type`, `Price`, `Added_By`, `Date`, `LastUpdatedDate`) VALUES
('Electrolyte and Homo', 700, 'Mekdes Adane', '2024-04-16', '05-06-24 01:01:50am'),
('STOOL', 10, 'Mekdes Adane', '2024-04-16', '07-03-24 01:05:24pm'),
('Coagulation', 100, 'Mekdes d', '2024-04-16', '23-04-24 10:07:'),
('Parasitology', 120, 'Mekdes d', '2024-04-16', '23-04-24 10:07:'),
('Clinical Chemistry', 150, 'Mekdes d', '2024-04-16', '23-04-24 10:07:'),
('Serology', 100, 'Mekdes d', '2024-04-16', '23-04-24 10:07:'),
('Urinalysis', 110, 'Mekdes d', '2024-04-16', '23-04-24 10:07:'),
('Hematology', 150, 'Mikiyas Adane', '2024-04-16', '24-04-24 03:01:23pm'),
('X-RAY', 50, 'Mikiyas Adane', '2024-04-24', ''),
('ULTRASOUND', 100, 'Mikiyas Adane', '2024-04-24', ''),
('MRI', 200, 'Mikiyas Adane', '2024-04-24', ''),
('CT-SCAN', 400, 'Mikiyas Adane', '2024-04-24', ''),
('ECHO', 400, 'Mikiyas Adane', '2024-04-24', '05-06-24 06:16:59pm');

-- --------------------------------------------------------

--
-- Table structure for table `user_db`
--

DROP TABLE IF EXISTS `user_db`;
CREATE TABLE IF NOT EXISTS `user_db` (
  `User_id` int NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `MiddleName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `LastName` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Sex` varchar(5) NOT NULL,
  `Age` int NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Role` varchar(20) NOT NULL,
  `Specialty` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `PhoneNumber` int NOT NULL,
  `Address` varchar(30) NOT NULL,
  `ProfilePicture` varchar(50) NOT NULL,
  `Date` varchar(10) NOT NULL,
  `LastUpdatedDate` varchar(30) NOT NULL,
  PRIMARY KEY (`User_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=FIXED;

--
-- Dumping data for table `user_db`
--

INSERT INTO `user_db` (`User_id`, `FirstName`, `MiddleName`, `LastName`, `Sex`, `Age`, `Username`, `Password`, `Role`, `Specialty`, `PhoneNumber`, `Address`, `ProfilePicture`, `Date`, `LastUpdatedDate`) VALUES
(1, 'Mikiyas', 'Adane', 'Biwota', 'Male', 21, 'miki', '$2y$10$ud4GiPBYzfHoqxxW9EuGYOwgYgXmPJ1n0b6n2NVXNhHA4L.DuMGq6', 'Administrator', 'Admin', 914606862, 'adiss abab', 'wp2595593-medical-wallpaper.jpg', '5/4/2024', '10-07-24 11:44:23am'),
(3, 'Mekdes', 'Adane', 'Biwota', 'Femal', 25, 'phar', '$2y$10$cypoWsW/AZE12Y8ybj7IseSNMky6M4WAAT/jTKPXfz7w6v/ckroFq', 'Pharmacist', 'Pharmacist', 941358500, 'Adiss Ababa', '66356cd746842.jpg', '05-03-24 1', '07-04-24 11:58:32pm'),
(4, 'Kalkidan', 'Alemu', 'Wedajo', 'Femal', 30, 'lab', '$2y$10$DNt7ZwCiAG2am7VDsIXjteR5oINP/9Npow0sd2gRBkAJIfeWOZw5i', 'Laboratorian', 'laboratorian', 953567898, 'Adiss Ababa', 'wp2595593-medical-wallpaper.jpg', '05-03-24 1', '07-04-24 11:56:35pm'),
(5, 'Selam', 'Mesfin', 'Nigus', 'Femal', 29, 'rad', '$2y$10$okE5NASYLeQklBic.5apVeMK/nuTzUJCYlLIYH4ITgOXvgFnSH/Au', 'Radiology', 'Rediologist', 945454544, 'Adiss Ababa', 'photo_2024-04-03_14-39-39.jpg', '05-03-24 1', '07-05-24 12:00:33am'),
(6, 'Almaz', 'Kebede', 'Chala', 'Femal', 32, 'cash', '$2y$10$n.5lpN3y1ddoeWM5pydOEej0ONbzoXnpUl4k//IPqjOKOb2kKvE06', 'Cashier', 'Cashier', 978654312, 'Adiss Ababa', 'photo_2020-05-28_14-02-32.jpg', '05-03-24 1', '07-05-24 12:03:03am'),
(8, 'Aster', 'Tesema', 'Znabu', 'Male', 25, 'rece', '$2y$10$gHGo1VitR4yXoSHmjEoGPuit1VHEjpP80pm0yO0REweT/7XI.zW2a', 'Reception', 'Reception', 973773345, 'Adiss Ababa', 'photo_2024-03-26_23-10-21.jpg', '05-04-24 0', '07-05-24 12:09:35am'),
(9, 'kebede', 'Bile', 'Abebe', 'Male', 40, 'doc', '$2y$10$FYVx/N.sqGfV5C.u/TMlr.rCPWnKiLmpfv.2WNBROGZLaQH4bH776', 'Doctor', 'internal', 911456729, 'Adiss Ababa', 'photo_2024-03-26_23-10-21.jpg', '05-05-24 0', '07-05-24 12:05:37am'),
(12, 'Abebe', 'Kebede', 'Chala', 'Male', 29, 'sono', '$2y$10$B4GLi6fKDwo90CUa6Kn2nOkOQkFilKrb.irYLf65xZw1k5XVHH9P.', 'Sonographer', 'Sonographer', 912532728, 'Adiss Ababa', 'photo_2024-03-26_23-08-05.jpg', '05-10-24 1', '07-05-24 12:11:12am'),
(21, 'sami', 'tilahun', '123', 'Male', 2001, 'samitt', '$2y$10$VpEGD14W3QF1fTo9wdnfX.YteTvvwZ6g.BwnXQz5e.4Qv/NQoBXDO', 'Reception', '', 949188651, 'addis', 'photo_2024-07-04_09-34-01.jpg', '07-05-24 0', ''),
(17, 'Daniel', 'Mulubirhan', 'abebe', 'Male', 23, 'dani', '$2y$10$nW6aYOmkdw99NV6GpqPBeuREHIVsohuTUPh5LE7./WIak0gKL7RTi', 'Administrator', 'Administrator', 929456816, 'adiss abab', 'photo_2024-07-03_14-02-16.jpg', '07-03-24 1', ''),
(18, 'Bahiru', 'Negash', 'beri', 'Male', 24, 'ethio@1140', '$2y$10$Md9VcqJ6gedBkbKxcWQBvOAqVRsxTMKzA3DtLI2pQSjGiDiDYc0C.', 'Administrator', 'Admin', 965912441, 'adiss abab/yeka', 'photo_2024-07-04_09-25-51.jpg', '07-04-24 0', ''),
(19, 'Samuel ', 'Tilahun', 'Deyaso', 'Male', 24, 'samit', '$2y$10$bmdeimP3ZcPo2WK0FDkoj.0dIt6WyaXdPU0XrZocbZ.nY0ghA.4qi', 'Administrator', 'Admin', 942861522, 'adiss abab/Bole', 'photo_2024-07-04_09-34-01.jpg', '07-04-24 0', ''),
(20, 'Besufikad ', 'Baye', 'Moges', 'Male', 22, 'bbmzc@123', '$2y$10$GCmVmfWXGeDVpFnAEkf7S.fdZFpfXF7xibwNYfz8V5cIzdjbvfqke', 'Administrator', 'Admin', 923514283, 'adiss abab/yeka', 'photo_2024-07-04_09-34-07.jpg', '07-04-24 0', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
